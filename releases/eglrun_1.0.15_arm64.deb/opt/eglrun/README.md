# eglrun — UOS / Kirin 9000c 硬件合成 + 相位锁定启动器

## 用途

`eglrun` 是唯一入口。自动识别 Chrome / Chromium 与 Electron 应用，一次性套用已验证修复集：

| 修复项 | 实现方式 |
|---|---|
| VAAPI 视频硬解 | `LIBVA_DRIVER_NAME=vacore` + `gbm-hw-shim.so` 把 vacore 的 VAAPI 1.14 伪装为 1.17 |
| 硬件合成（不闪不果冻） | `--enable-gpu-compositing` + GBM dma-buf 路径，**配合 VSYNC 相位锁定**（见下） |
| **VSYNC 相位锁定** | `wire-damage-shim.so` 把每帧提交间隔钉在 vsync 整数倍 `k*T`（T=16678µs），果冻/撕裂彻底消失 |
| GPU 侧真同步 | `gbm-hw-shim.so` 在 `gbm_bo_get_fd_for_plane()`（唯一有 EGL 上下文的每帧点）调 `glFinish()`，确保 buffer 写完才交 KWin |
| WebGL | `--use-angle=gl` → ANGLE (HUAWEI, Maleoon 910, OpenGL ES 3.2) |
| DPI | 读取 DDE 私有键 `com.deepin.xsettings scale-factor`，注入 `--force-device-scale-factor` |
| 鼠标指针 | `cursor-wire-shim.so` 在 Wayland 字节流层把 `set_buffer_scale(2)` 改为 1 |
| 窗口崩溃 | `pointer_guard.so` 补齐 Chrome 缺失的 wl_pointer warp(opcode 11) handler，修掉最大化/还原 SIGABRT |
| 任务栏图标 | Chrome 类型注入 `--class=google-chrome` |
| 视频抖屏 | 默认关闭 `AcceleratedVideoDecodeLinuxZeroCopyGL`（HUAWEI libEGL 的 `eglCreateImage` 0x3004 会闪） |
| Electron 启动污染 | 清理 `ELECTRON_RUN_AS_NODE` / `NODE_OPTIONS`；同级有 `libspawn_shim.so` 时自动加载 |

## 相位锁定为什么能消除果冻

Maleoon 平台没有跨进程 dma-buf fence（华为驱动 `hvgr_ksync_create_dma_fence` 恒为 0，内核 kprobe 铁证）。KWin 拿不到 fence，只能凭时间猜 buffer 是否写完——猜错就扫到半张画面，表现为「果冻 / 撕裂 / 局部卡旧画面」。

本方案不去修 fence（那需要改内核），而是**让提交时刻与 vsync 严格对齐**：

```
S = net + delay          S = 相邻两次提交的间隔
net = interval - last_applied_delay    剥离自身注入后的真实渲染耗时
delay = k*T - net        前馈抵消
=> S ≡ k*T               恒为 vsync 整数倍
```

KWin 每次都在**同一个扫描位置**取样 buffer，半写状态永远暴露不出来。

### HYBRID 混合目标模式

固定 `k=2` 时，重帧（`net > 2T`）的 `delay` 会被截断为 0，该帧提交时刻失控 → 相位漂移 → **残余果冻**。实测 943 帧真实 aistudio 数据：

| 方案 | 锁相率 | 失锁帧 | 帧率 |
|---|---|---|---|
| 固定 k=2 | 88.65% | 12.73% | 30fps |
| **HYBRID kmax=4** | **99.89%** | **0.11%** | 30fps |

HYBRID 逐帧选「使 `delay ≥ 0` 的最小 k」，重帧自动升到 3T/4T 获得足够 settle 时间；降档带滞回（`WIRE_LOCK_HYBRID_HOLD` 帧）避免 k 边界横跳。

真实 Chrome A/B（three.js，1000 帧）：固定 k=2 失锁 2 帧，HYBRID 失锁 **0 帧**，帧率同为 30.0fps。

### 30fps 不是硬件限制

参考负载下 62% 的帧渲染耗时 < 16.7ms（GPU 有 60fps 能力），但 42% 超过一个 vsync 周期，全程 `k=1` 会丢帧。`k=2` 保证每帧完整且相位恒锁，是当前最稳的选择。提帧率需要提升 GPU 渲染能力，与上屏垫片无关。

## 用法

```bash
eglrun ~/Downloads/Chrome.AppImage          # 自动识别为 Chromium
eglrun /opt/xxx/electron-bin                # 自动识别为 Electron
eglrun --chrome /path/to/binary             # 强制 Chromium 参数集
eglrun --electron /path/to/binary           # 强制 Electron 参数集
eglrun --dry-run <app>                      # 只打印解析后的命令
eglrun --help
```

无需配置任何环境变量；`env.sh` 内部的 VAAPI 变量、锁相参数与垫片是唯一需要的环境。

### 常用调参（覆盖环境变量即可）

| 变量 | 默认 | 说明 |
|---|---|---|
| `WIRE_LOCK` | 1 | 相位锁定总开关 |
| `WIRE_LOCK_K` | 2 | 基础倍数 → 2T = 33.356ms = 30fps |
| `WIRE_LOCK_T` | 16678 | vsync 周期（µs，59.96Hz） |
| `WIRE_LOCK_HYBRID` | 1 | 逐帧 k 选择（消除残余果冻） |
| `WIRE_LOCK_HYBRID_KMAX` | 4 | 单帧可升到的最高 k |
| `WIRE_LOCK_HYBRID_HOLD` | 8 | 降档所需连续轻帧数 |
| `GPU_FINISH_SYNC` | 1 | GPU 侧 glFinish 真同步 |

**输入法已解耦**：Wayland 输入法（KWin `InputMethod`、`wayland-im-shim`、CPIS uinput DBus 策略、搜狗/fcitx 支持）由独立的 `uoshim-wayland-im` 包提供，本包通过 `Depends: uoshim-wayland-im` 声明依赖，**不写 kwinrc、不碰 CPIS policy、不含任何输入法二进制或 desktop 文件**。

AppImage **原地运行**，不做持久解包。AppImage runtime 会把 `LD_PRELOAD` 与 `LIBVA_*` 传给内部 Chrome，垫片照常生效。

## 排错：Diagnostics（默认全部关闭）

发行版默认**不写任何日志文件、不输出任何调试信息**。仅在需要排查时，为单次运行手动开启对应变量：

| 变量 | 效果 |
|---|---|
| `WIRE_DEBUG=1` | 逐帧锁相轨迹 → `/tmp/wire-commit-shim.log` |
| `WIRE_COMMIT_LOG=/path/x.log` | 同上，但指定输出路径 |
| `GPU_FINISH_DEBUG=1` | glFinish 命中计数 → `/tmp/gpu-finish-shim.log` |
| `HISI_GBM_SHIM_DEBUG=1` | GBM 桥接调用轨迹 → stderr + `/tmp/gbm-hw-loaded.txt` |
| `CURSOR_SHIM_DEBUG=1` | 光标 surface 改写轨迹 → `/tmp/cursor-wire-shim.log` |
| `POINTER_GUARD_DEBUG=1` | 指针 listener 包装信息 → stderr |

示例（只影响这一次启动）：

```bash
WIRE_DEBUG=1 eglrun /opt/google-chrome/chrome
```

所有开关遵循严格布尔语义：只有 `1` 开启，`0` 明确关闭。

## 目录

```
/opt/eglrun/bin/      命令：eglrun、check-accel
/opt/eglrun/lib/      原生垫片：gbm-hw-shim.so、cursor-wire-shim.so、pointer_guard.so、wire-damage-shim.so
/opt/eglrun/src/      垫片源码 + build.sh（可复现编译）
/opt/eglrun/config/   部署配置（仅 environment.d）
/usr/local/bin/eglrun -> /opt/eglrun/bin/eglrun
```

`bash src/build.sh` 可在同环境重新编译四个垫片到 `lib/`（需 gcc）。

安装由 deb 的 `postinst` 自动完成（全局命令 + VAAPI environment.d），无需手动创建桌面入口。输入法相关的登录部署由 `uoshim-wayland-im` 负责。
