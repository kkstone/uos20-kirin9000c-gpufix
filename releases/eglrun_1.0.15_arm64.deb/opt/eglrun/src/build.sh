#!/bin/sh
# Rebuild all native helpers from source into ../lib.
# Run on the same UOS 20 / aarch64 environment as the target machine.
# The Wayland IM bridge is provided by the separate uoshim-wayland-im package
# and is intentionally not built here.
set -e
cd "$(dirname "$0")"
ROOT="$(cd .. && pwd)"

echo "== gbm-hw-shim.so -> $ROOT/lib =="
gcc -shared -fPIC -O2 -ldl -o "$ROOT/lib/gbm-hw-shim.so" gbm-hw-shim.c

echo "== cursor-wire-shim.so -> $ROOT/lib =="
gcc -shared -fPIC -O2 -ldl -o "$ROOT/lib/cursor-wire-shim.so" cursor-wire-shim.c

echo "== wire-damage-shim.so -> $ROOT/lib =="
gcc -shared -fPIC -O2 -ldl -o "$ROOT/lib/wire-damage-shim.so" wire-damage-shim.c

echo "== pointer_guard.so -> $ROOT/lib =="
gcc -shared -fPIC -O2 -ldl -lwayland-client -o "$ROOT/lib/pointer_guard.so" pointer_guard.c

echo "done."
