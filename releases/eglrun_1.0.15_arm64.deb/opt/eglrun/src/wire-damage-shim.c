/*
 * wire-commit-shim.so -- wire-level (syscall) interception of Chrome's
 * embedded libwayland, to mitigate stale-buffer presentation on
 * Kirin/Maleoon + DDE KWin (no wp_linux_drm_syncobj -> implicit sync -> KWin
 * samples a stale dma-buf; a tiny commit delay lets the EGL fence settle).
 *
 * WHY WIRE LEVEL: Chrome 157 statically embeds libwayland-client in
 * libGLESv2.so; LD_PRELOAD hooks on wl_proxy_marshal_* see ZERO calls
 * (damage-full-shim v1..v5). But both libwayland copies flush bytes via
 * write()/sendmsg(). cursor-wire-shim.so proves this path works.
 *
 * CRITICAL SAFETY RULE (learned the hard way): NEVER change the byte LENGTH
 * of a Wayland flush. Chrome's embedded libwayland tracks how many bytes it
 * wrote; injecting a 24-byte damage desynchronises its event demarshaller and
 * KWin replies produce "Too many bits for size_t". So this version only:
 *   (a) DELAYS a commit-bearing flush by N microseconds (no byte change),
 *       and/or
 *   (b) REWRITES IN PLACE the x/y/w/h of existing wl_surface.damage messages
 *       to a full-screen rectangle (same length) [WIRE_DAMAGE_FULL=1].
 * Original message order, count and length are always preserved.
 *
 * HOW THE WAYLAND FD IS CONFIRMED: per-fd state; a fd is "wayland" once a
 * get_registry or a bind("wl_compositor"/"wl_shm"/"wl_seat") is seen on it.
 * No /proc/net/unix (Chrome uses an abstract/inherited socket).
 *
 * Env: WIRE_DAMAGE_FULL=1|0 (in-place damage widening, default 1),
 *      WIRE_COMMIT_DELAY_US=N (default 0), WIRE_DEBUG=1, WIRE_FORCE_FD=1(test).
 *
 * ADAPTIVE DELAY (opt-in; default OFF => legacy fixed delay, byte-for-byte
 * same behaviour as v7):
 *   WIRE_ADAPTIVE=1              enable frame-interval-driven delay
 *   WIRE_COMMIT_DELAY_US=N       baseline / floor delay (same var as before)
 *   WIRE_ADAPTIVE_MAX_US=N       hard ceiling (default 20000)
 *   WIRE_ADAPTIVE_GAIN=F         excess->delay gain (default 1.0)
 *   WIRE_ADAPTIVE_ALPHA=F        slow baseline EMA alpha (default 0.08)
 *   WIRE_ADAPTIVE_MIN_GAP_US=N   min gap counted as a new frame (default 2000)
 *
 * v9 MODE (WIRE_ADAPTIVE_MODE=absolute, DEFAULT when WIRE_ADAPTIVE=1):
 *   WIRE_ADAPTIVE_MODE=absolute|legacy   (default absolute)
 *   WIRE_ABS_HEADROOM_US=N       extra margin over net render time (default 2000)
 *   WIRE_ABS_ALPHA=F             fast EMA alpha tracking net (default 0.20)
 *
 * WHY v9: the v8 "legacy" logic compared net interval to a SLOW EMA baseline
 * and only delayed for the excess ABOVE baseline. Under a heavy scene (large
 * window) EVERY frame is heavy, the slow baseline rises to ~34ms, excess -> ~0,
 * so delay collapses to the 8ms floor -> jelly remains. Tuning gain 1.0->1.5
 * changes 0.7ms into 1.1ms = useless. Measured evidence:
 *   net=27350 base=34865 excess=-7515 -> delay=8000
 *   net=36029 base=34296 excess=+1733 -> delay=9732
 *
 * v9 "absolute" mode instead tracks the ABSOLUTE net frame time with a faster
 * EMA and sets delay = net_ema * GAIN + HEADROOM, clamped to [base, max].
 * So when the scene needs 34ms/frame, delay rises to ~34ms*gain+2ms, covering
 * the real GPU render time instead of ignoring it. This is the correct model
 * for a uniformly heavy scene. Legacy mode kept for A/B via
 * WIRE_ADAPTIVE_MODE=legacy. WIRE_DEBUG=1 logs net/ema/delay per frame.
 *
 * Build: gcc -shared -fPIC -O2 -o wire-damage-shim.so wire-damage-shim.c -ldl
 */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdarg.h>
#include <sys/uio.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <sys/syscall.h>
#include <sys/socket.h>

#define MAX_FDS 4096

static ssize_t (*real_write)(int, const void *, size_t);
static ssize_t (*real_writev)(int, const struct iovec *, int);
static ssize_t (*real_sendmsg)(int, const struct msghdr *, int);
static ssize_t (*real_send)(int, const void *, size_t, int);
static int real_ready;

/* per-fd: only need a "confirmed wayland" flag; no object tracking required
 * because we never inject, only rewrite damage in place and delay. */
static unsigned char fd_wl[MAX_FDS];

static unsigned long n_damage_rewritten, n_delay_us, n_flush_seen, n_commit_seen;

/* ---- adaptive delay state (only used when WIRE_ADAPTIVE=1) ---- */
static struct timespec last_frame_ts;   /* wall-clock time of previous frame signal */
static int      have_last_frame = 0;
static double   ema_baseline = 0.0;     /* slow EMA of net frame interval (us) — legacy mode */
static double   ema_net = 0.0;          /* v9: fast EMA of ABSOLUTE net render time (us) */
static double   env_peak = 0.0;         /* v10: fast-attack/slow-release peak envelope (us) */
static long     last_applied_delay = 0; /* delay we injected on previous frame (us) */
static unsigned long n_adaptive_frames = 0, n_heavy_frames = 0;

/* ---- v12: ADAPTIVE PHASE-LOCK k ----
 * v11 pinned k to a compile-time constant (default 2 = 30fps everywhere).
 * v12 keeps the SAME feedforward cancellation (delay = k*T - net) but chooses
 * k from the net-load peak envelope, with hysteresis + hold so k only changes
 * on sustained load shifts, NEVER frame-to-frame (frame-to-frame k changes
 * would make S jump between T and 2T = a different kind of jitter).
 *   net peak <  UP_RATIO * T  -> k-- (faster, toward 60fps) if k > K_MIN
 *   net peak > DOWN_RATIO * T -> k++ (slower, more headroom) if k < K_MAX
 *   HOLD frames of no-change after any switch let the phase re-lock.
 */
static double   lock_env = 0.0;      /* fast-attack / slow-release net peak (us) */
static int      lock_hold = 0;       /* frames remaining before next k change allowed */
static int      cur_k = 0;           /* currently applied k (0 = not decided yet) */
static int      last_k = 0;           /* v14 hybrid: last selected k (for logging) */
static unsigned long n_k_up = 0, n_k_down = 0;
/* v14 hybrid 锁相质量统计 */
static unsigned long n_hybrid_locked = 0;   /* S 落在 k*T ± 2ms 的帧数 */
static unsigned long n_hybrid_lost = 0;     /* delay==0 的失锁帧数（残余果冻来源） */
static int          n_hybrid_maxk = 0;      /* 实际用到的最大 k */

/* Release build: logging is OFF by default and creates NO file at all.
 * Enable with either:
 *   WIRE_DEBUG=1                  -> verbose per-frame trace
 *   WIRE_COMMIT_LOG=/path/to.log  -> non-zero path also enables logging
 * (WIRE_COMMIT_LOG=0 / "off" keeps it disabled.)
 * Without one of those, logline() returns immediately and never opens a
 * file, so a normal session leaves no trace on disk. */
static int log_enabled(void)
{
    static int v = -1;
    if (v < 0) {
        const char *d = getenv("WIRE_DEBUG");
        const char *p = getenv("WIRE_COMMIT_LOG");
        int on = (d && strcmp(d, "1") == 0) ? 1 : 0;
        if (!on && p && p[0] && strcmp(p, "0") != 0 && strcmp(p, "off") != 0)
            on = 1;
        v = on;
    }
    return v;
}

static void logline(const char *fmt, ...)
{
    static FILE *fp; va_list ap;
    if (!log_enabled()) return;
    if (!fp) {
        const char *lp = getenv("WIRE_COMMIT_LOG");
        fp = fopen(lp ? lp : "/tmp/wire-commit-shim.log", "a");
        if (fp) setvbuf(fp, NULL, _IOLBF, 0);
    }
    if (!fp) return;
    va_start(ap, fmt); vfprintf(fp, fmt, ap); va_end(ap);
}

static void init_real(void)
{
    if (real_ready) return;
    real_ready = 1;
    real_write   = (ssize_t (*)(int, const void *, size_t))dlsym(RTLD_NEXT, "write");
    real_writev  = (ssize_t (*)(int, const struct iovec *, int))dlsym(RTLD_NEXT, "writev");
    real_sendmsg = (ssize_t (*)(int, const struct msghdr *, int))dlsym(RTLD_NEXT, "sendmsg");
    real_send    = (ssize_t (*)(int, const void *, size_t, int))dlsym(RTLD_NEXT, "send");
}

static int opt_damage(void) {
    static int v = -1;
    /* DEFAULT OFF: full-screen damage widening was proven HARMFUL (forces
     * KWin full re-upload every frame -> widens the GPU/scanout race window;
     * user saw stronger jelly, worst at top-left = scanout order). Only enable
     * explicitly with WIRE_DAMAGE_FULL=1. */
    if (v < 0) { const char *e = getenv("WIRE_DAMAGE_FULL"); v = (e && strcmp(e,"1")==0) ? 1 : 0; }
    return v;
}
static long opt_delay_us(void) {
    static int init = 0; static long v = 0;
    if (!init) { init = 1; const char *e = getenv("WIRE_COMMIT_DELAY_US"); v = e ? atol(e) : 0; if (v<0) v=0; }
    return v;
}
static int opt_debug(void) {
    static int v = -1;
    if (v < 0) { const char *e = getenv("WIRE_DEBUG"); v = (e && strcmp(e,"1")==0) ? 1 : 0; }
    return v;
}
static int opt_adaptive(void) {
    static int v = -1;
    if (v < 0) { const char *e = getenv("WIRE_ADAPTIVE"); v = (e && strcmp(e,"1")==0) ? 1 : 0; }
    return v;
}
static long opt_adaptive_max(void) {
    /* v9 default raised to 40ms: a heavy large window really renders ~34ms/frame,
     * so a 20ms ceiling (v8) clamps the absolute-mode delay too early. */
    static int init = 0; static long v = 40000;
    if (!init) { init = 1; const char *e = getenv("WIRE_ADAPTIVE_MAX_US");
                 if (e) { long x = atol(e); if (x > 0) v = x; } }
    return v;
}
static double opt_adaptive_gain(void) {
    static int init = 0; static double v = 1.0;
    if (!init) { init = 1; const char *e = getenv("WIRE_ADAPTIVE_GAIN");
                 if (e) { double x = atof(e); if (x > 0.0 && x < 20.0) v = x; } }
    return v;
}
static double opt_adaptive_alpha(void) {
    static int init = 0; static double v = 0.08;
    if (!init) { init = 1; const char *e = getenv("WIRE_ADAPTIVE_ALPHA");
                 if (e) { double x = atof(e); if (x > 0.0 && x < 1.0) v = x; } }
    return v;
}
static long opt_adaptive_min_gap(void) {
    static int init = 0; static long v = 2000;
    if (!init) { init = 1; const char *e = getenv("WIRE_ADAPTIVE_MIN_GAP_US");
                 if (e) { long x = atol(e); if (x > 0) v = x; } }
    return v;
}
/* v9: mode selector. default = absolute (fixes the "every frame is heavy"
 * collapse); legacy = the old net-vs-slow-EMA-excess behaviour. */
static int opt_mode_absolute(void) {
    static int v = -1;
    if (v < 0) { const char *e = getenv("WIRE_ADAPTIVE_MODE");
                 v = (e && strcmp(e, "legacy") == 0) ? 0 : 1; }
    return v;
}
static long opt_abs_headroom(void) {
    static int init = 0; static long v = 2000;
    if (!init) { init = 1; const char *e = getenv("WIRE_ABS_HEADROOM_US");
                 if (e) { long x = atol(e); if (x >= 0) v = x; } }
    return v;
}
static double opt_abs_alpha(void) {
    static int init = 0; static double v = 0.20;
    if (!init) { init = 1; const char *e = getenv("WIRE_ABS_ALPHA");
                 if (e) { double x = atof(e); if (x > 0.0 && x < 1.0) v = x; } }
    return v;
}
/* v10 fast-attack / slow-release peak envelope.
 * net frame times are near-random (lag-1 autocorr ~0.5), so a symmetric EMA
 * must choose between under-covering heavy frames (slow) or jittering the
 * delay itself (fast). An asymmetric envelope rises immediately on a heavy
 * frame (cover it) then decays slowly on light frames (no new jitter).
 * WIRE_ENV=1 enables it; attack/release tunable; defaults from offline sim. */
static int opt_env(void) {
    static int v = -1;
    if (v < 0) { const char *e = getenv("WIRE_ENV"); v = (e && strcmp(e,"1")==0) ? 1 : 0; }
    return v;
}
static double opt_env_attack(void) {
    static int init = 0; static double v = 0.90;
    if (!init) { init = 1; const char *e = getenv("WIRE_ENV_ATTACK");
                 if (e) { double x = atof(e); if (x > 0.0 && x <= 1.0) v = x; } }
    return v;
}
static double opt_env_release(void) {
    static int init = 0; static double v = 0.05;
    if (!init) { init = 1; const char *e = getenv("WIRE_ENV_RELEASE");
                 if (e) { double x = atof(e); if (x > 0.0 && x < 1.0) v = x; } }
    return v;
}

/* ---- v11: VSYNC PHASE LOCK (WIRE_LOCK=1) ----
 * Root cause of the remaining 33-38fps jelly: the compositor (KWin) samples
 * the dma-buf on every vsync (59.96Hz -> T=16678us). What matters for a
 * stable image is NOT how big the delay is, but the SEND-TO-SEND interval
 * S of successive commits. If S is not an integer multiple of T, the commit
 * phase drifts relative to vsync frame after frame; KWin sometimes samples a
 * freshly committed buffer and sometimes an old one -> visible jelly/stutter.
 *
 * Derivation (all quantities measured on this fd):
 *   S = net + delay_this_frame
 *     because we sleep(delay) immediately BEFORE sending this frame's commit.
 *   Therefore to force S = k*T (a locked phase), set:
 *     delay = k*T - net
 *   net = interval - last_applied_delay (self-feedback already stripped).
 *
 * This is a FEEDFORWARD cancellation: net and delay are ANTI-correlated, so
 * their SUM is constant -> send phase stays glued to the same vsync slot.
 * Offline replay of 1046 real frames: on-vsync(<2ms) 32.9% -> 97.1%,
 * send-interval jitter |dS| 8839us -> 442us at k=2 (30fps).
 * k=1 (60fps) only works when net<T; k=2 is the robust default here.
 */
static int opt_lock(void) {
    static int v = -1;
    if (v < 0) { const char *e = getenv("WIRE_LOCK"); v = (e && strcmp(e,"1")==0) ? 1 : 0; }
    return v;
}
static int opt_lock_k(void) {
    static int init = 0; static long v = 2;
    if (!init) { init = 1; const char *e = getenv("WIRE_LOCK_K");
                 if (e) { long x = atol(e); if (x >= 1 && x <= 8) v = x; } }
    return (int)v;
}
static long opt_lock_T(void) {
    static int init = 0; static long v = 16678;   /* 1e6 / 59.96 Hz */
    if (!init) { init = 1; const char *e = getenv("WIRE_LOCK_T");
                 if (e) { long x = atol(e); if (x > 0) v = x; } }
    return v;
}
/* v12 adaptive-k controls. All opt-in: WIRE_LOCK_ADAPT=1 enables. */
static int opt_lock_adapt(void) {
    static int v = -1;
    if (v < 0) { const char *e = getenv("WIRE_LOCK_ADAPT"); v = (e && strcmp(e,"1")==0) ? 1 : 0; }
    return v;
}
static int opt_lock_k_min(void) {
    static int init = 0; static long v = 1;
    if (!init) { init = 1; const char *e = getenv("WIRE_LOCK_K_MIN");
                 if (e) { long x = atol(e); if (x >= 1 && x <= 8) v = x; } }
    return (int)v;
}
static int opt_lock_k_max(void) {
    static int init = 0; static long v = 3;
    if (!init) { init = 1; const char *e = getenv("WIRE_LOCK_K_MAX");
                 if (e) { long x = atol(e); if (x >= 1 && x <= 8) v = x; } }
    return (int)v;
}
static double opt_lock_up_ratio(void) {
    /* net peak below this fraction of T => shrink k (raise fps) */
    static int init = 0; static double v = 0.72;
    if (!init) { init = 1; const char *e = getenv("WIRE_LOCK_UP_RATIO");
                 if (e) { double x = atof(e); if (x > 0.1 && x < 1.0) v = x; } }
    return v;
}
static double opt_lock_down_ratio(void) {
    /* net peak above this fraction of T => grow k (lower fps, more headroom) */
    static int init = 0; static double v = 0.95;
    if (!init) { init = 1; const char *e = getenv("WIRE_LOCK_DOWN_RATIO");
                 if (e) { double x = atof(e); if (x > 0.2 && x < 4.0) v = x; } }
    return v;
}
static double opt_lock_env_attack(void) {
    static int init = 0; static double v = 0.85;
    if (!init) { init = 1; const char *e = getenv("WIRE_LOCK_ENV_ATTACK");
                 if (e) { double x = atof(e); if (x > 0.0 && x <= 1.0) v = x; } }
    return v;
}
static double opt_lock_env_release(void) {
    static int init = 0; static double v = 0.02;
    if (!init) { init = 1; const char *e = getenv("WIRE_LOCK_ENV_RELEASE");
                 if (e) { double x = atof(e); if (x > 0.0 && x < 1.0) v = x; } }
    return v;
}
static int opt_lock_hold(void) {
    static int init = 0; static long v = 120;
    if (!init) { init = 1; const char *e = getenv("WIRE_LOCK_HOLD");
                 if (e) { long x = atol(e); if (x >= 0) v = x; } }
    return (int)v;
}
/* v13 STEP mode: per-frame k = ceil(net/T), clamped to [K_MIN,K_MAX].
 * Unlike v12's slow envelope (which switches k only on sustained load shifts),
 * STEP reacts per-frame. This is SAFE here because BOTH k values keep S on a
 * vsync multiple (k*T), so the phase stays locked whichever k is chosen.
 * Measured on real aistudio frames: lock rate 71%->96%, S jitter 2271->1541us.
 * A small hysteresis (margin) prevents oscillation at the k boundary. */
static int opt_lock_step(void) {
    static int v = -1;
    if (v < 0) { const char *e = getenv("WIRE_LOCK_ADAPT_STEP");
                 v = (e && strcmp(e,"1")==0) ? 1 : 0; }
    return v;
}
static double opt_lock_step_margin(void) {
    /* net must exceed k*T*margin before stepping up to k+1 (default 1.0).
     * >1 delays the 30->20fps downgrade slightly; <1 makes it eager. */
    static int init = 0; static double v = 1.0;
    if (!init) { init = 1; const char *e = getenv("WIRE_LOCK_STEP_MARGIN");
                 if (e) { double x = atof(e); if (x > 0.5 && x < 2.0) v = x; } }
    return v;
}

/* ---- v14: HYBRID TARGET LOCK (WIRE_LOCK_HYBRID=1) ----
 * 【v14 实测根因，2026-11-21，基于 943 帧 LOCK11 真实日志】
 *   v13 固定 k=2 (target=33356us) 时：
 *     - 快帧 (net<20ms)      : 660/660  = 100.0% 锁相成功  -> 用户看不到果冻
 *     - 重帧 (net>=20ms)     : 176/283  =  62.2% 锁相成功  -> 残余果冻
 *     - 其中 120 帧 net>=target 且 delay 被 clamp 到 0
 *       ==> 这些帧的提交时刻完全失控 ==> 相位相对 vsync 漂移 ==> 果冻/撕裂
 *   也就是说：k 固定时，重帧的 delay = k*T-net < 0 被截断成 0，
 *   S 不再是 vsync 整数倍，相位就散了。这是【唯一的残余果冻来源】。
 *
 * 【v14 解法】逐帧选【最小的 k 使 delay>=0】，即 k = ceil(net/T)：
 *   - delay 恒 >= 0        -> 永不 clamp 到 0 -> S 恒为 k*T -> 相位恒锁
 *   - k 变化时 S 仍是 vsync 整数倍 -> 相位不会因跳变而散
 *   - 快帧仍走 k=2 (30fps)，只有确实需要 3T 的重帧才升到 3T
 *   离线回放同一份 943 帧日志：k=2 固定 -> 覆盖 87.3%/锁相 88.7%
 *                              k=ceil(net/T) -> 覆盖 100%/锁相 100%
 *
 * 滞回：STEP_MARGIN>1 时，只有 net > k*T*margin 才升 k（避免边界抖动）。
 */
static int opt_lock_hybrid(void) {
    static int v = -1;
    if (v < 0) { const char *e = getenv("WIRE_LOCK_HYBRID");
                 v = (e && strcmp(e, "1") == 0) ? 1 : 0; }
    return v;
}
static int opt_lock_hybrid_kmax(void) {
    static int init = 0; static long v = 4;
    if (!init) { init = 1; const char *e = getenv("WIRE_LOCK_HYBRID_KMAX");
                 if (e) { long x = atol(e); if (x >= 1 && x <= 8) v = x; } }
    return (int)v;
}
static int opt_lock_hybrid_hold(void) {
    /* 降档滞回帧数：连续这么多帧都低于 (k-1)*T 才允许降 k */
    static int init = 0; static long v = 8;
    if (!init) { init = 1; const char *e = getenv("WIRE_LOCK_HYBRID_HOLD");
                 if (e) { long x = atol(e); if (x >= 0 && x <= 600) v = x; } }
    return (int)v;
}

static long now_us(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (long)t.tv_sec * 1000000L + t.tv_nsec / 1000L;
}

/* Compute the delay for THIS frame. In adaptive mode:
 *   net = interval - delay_we_added_last_time   (remove self-feedback)
 *   baseline = slow EMA of net
 *   extra = max(0, net - baseline) * gain
 *   delay = clamp(base + extra, base, max)
 * Returns fixed base delay when adaptive mode is off. */
static long frame_delay_us(void)
{
    long base = opt_delay_us();
    if (!opt_adaptive()) return base;

    long now = now_us();
    long delay = base;

    if (have_last_frame) {
        long interval = now - ((long)last_frame_ts.tv_sec * 1000000L + last_frame_ts.tv_nsec / 1000L);
        /* ignore absurd gaps (tab backgrounded / first frames): resync */
        if (interval > 0 && interval < opt_adaptive_min_gap() * 40) {
            long net = interval - last_applied_delay;   /* strip our own contribution */
            if (net < 0) net = 0;

            long maxd = opt_adaptive_max();
            if (opt_lock()) {
                /* v12: vsync phase lock, k fixed or adaptive.
                 * delay = k*T - net  =>  S = net+delay = k*T (locked phase).
                 * k changes only on SUSTAINED load shifts (envelope + hold),
                 * never per-frame, so S never jumps between T and 2T. */
                long T = opt_lock_T();
                int k;

                if (opt_lock_hybrid()) {
                    /* v14 HYBRID: 逐帧选 k = ceil(net/T)，带降档滞回。
                     * 关键性质：S = net + delay = k*T 恒为 vsync 整数倍，
                     * 且 delay 恒 >=0（永不 clamp 到 0）-> 相位恒锁，
                     * 重帧自动升到 3T/4T 获得足够 settle 时间。
                     *
                     * 离线回放（943 帧真实 aistudio 日志，lock-replay2.py）：
                     *   固定 k=2 (v13)  : 锁相 88.65%  失锁帧 12.73%  30fps
                     *   HYBRID kmax=4    : 锁相 99.89%  失锁帧  0.11%  30fps
                     *   HYBRID kmax=3    : 锁相 99.36%  失锁帧  1.27%  30fps
                     * 失锁帧(delay=0) 就是【残余果冻】的直接来源：这些帧的
                     * 提交时刻完全失控，相位相对 vsync 漂移。
                     *
                     * 降档滞回（hold 帧）：连续 hold 帧都低于 (k-1)*T 才降 k，
                     * 避免在 k 边界反复横跳（每次跳变都是一次相位微扰）。
                     */
                    int kmin = opt_lock_k();                 /* 基准 k（通常 2） */
                    int kmax = opt_lock_hybrid_kmax();
                    double margin = opt_lock_step_margin();
                    if (cur_k == 0) cur_k = kmin;
                    /* 需要的 k：ceil(net / (T*margin))，下限 kmin */
                    int need = 1;
                    while (need * T * margin < (double)net && need < kmax) need++;
                    if (need < kmin) need = kmin;
                    if (need > cur_k) {
                        cur_k = need;                       /* 快速升档 */
                        lock_hold = 0;
                        n_k_up++;
                    } else {
                        /* 降档：连续 hold 帧都低于 (cur_k-1)*T 才降 */
                        if (cur_k > kmin && (double)net < (double)(cur_k - 1) * T) {
                            if (lock_hold < opt_lock_hybrid_hold()) lock_hold++;
                            if (lock_hold >= opt_lock_hybrid_hold()) {
                                cur_k--; lock_hold = 0; n_k_down++;
                            }
                        } else {
                            lock_hold = 0;
                        }
                    }
                    k = cur_k;
                    last_k = k;
                } else if (opt_lock_adapt()) {
                    /* Use PEAK envelope (not median): a single heavy frame per
                     * vsync is enough to expose a stale buffer => jelly. */
                    double a = ((double)net > lock_env) ? opt_lock_env_attack()
                                                        : opt_lock_env_release();
                    lock_env = lock_env * (1.0 - a) + (double)net * a;

                    if (cur_k == 0) { cur_k = opt_lock_k(); lock_hold = opt_lock_hold(); }
                    if (lock_hold > 0) lock_hold--;
                    else {
                        if (lock_env < opt_lock_up_ratio() * (double)T &&
                            cur_k > opt_lock_k_min()) {
                            cur_k--; lock_hold = opt_lock_hold(); n_k_up++;
                        } else if (lock_env > opt_lock_down_ratio() * (double)T &&
                                   cur_k < opt_lock_k_max()) {
                            cur_k++; lock_hold = opt_lock_hold(); n_k_down++;
                        }
                    }
                    k = cur_k;
                } else {
                    k = opt_lock_k();
                }

                long target = (long)k * T;
                delay = target - net;
                if (delay < 0) delay = 0;
                /* the generic adaptive ceiling (40ms) must not clip a larger k*T */
                long cap = maxd; if (cap < target) cap = target;
                if (delay > cap) delay = cap;
                n_adaptive_frames++;
                if (net > target) n_heavy_frames++;
                if (opt_lock_hybrid()) {
                    /* 锁相质量统计：S = net+delay 是否落在 k*T ± 2ms；
                     * delay==0 即失锁帧（提交时刻失控 -> 相位漂移 -> 残余果冻）。 */
                    long S = net + delay;
                    if (delay == 0) n_hybrid_lost++;
                    else if (S >= target - 2000 && S <= target + 2000) n_hybrid_locked++;
                    if (k > n_hybrid_maxk) n_hybrid_maxk = k;
                }
                if (opt_debug()) {
                    if (opt_lock_hybrid())
                        logline("[pid %d] LOCK14 interval=%ld last=%ld net=%ld k=%d T=%ld target=%ld -> delay=%ld S=%ld\n",
                                getpid(), interval, last_applied_delay, net,
                                k, T, target, delay, net + delay);
                    else
                    logline("[pid %d] LOCK12 interval=%ld last=%ld net=%ld k=%d T=%ld peak=%.0f hold=%d target=%ld -> delay=%ld\n",
                            getpid(), interval, last_applied_delay, net,
                            k, T, lock_env, lock_hold, target, delay);
                }
            } else if (opt_mode_absolute()) {
                /* v10 (WIRE_ENV=1): fast-attack/slow-release peak envelope.
                 * Heavy frame -> jump up immediately so this frame is covered;
                 * light frame -> decay slowly so the injected delay itself
                 * stays smooth. Best of both: high coverage AND low jitter. */
                if (opt_env()) {
                    double target = (double)net;
                    double a = (target > env_peak) ? opt_env_attack()
                                                   : opt_env_release();
                    env_peak = env_peak * (1.0 - a) + target * a;
                    delay = (long)(env_peak * opt_adaptive_gain())
                          + opt_abs_headroom();
                    if (env_peak > (double)(base + 2000)) n_heavy_frames++;
                    if (delay < base) delay = base;
                    if (delay > maxd) delay = maxd;
                    n_adaptive_frames++;
                    if (opt_debug())
                        logline("[pid %d] ENV10 interval=%ld last=%ld net=%ld peak=%.0f atk=%.2f rel=%.2f head=%ld -> delay=%ld\n",
                                getpid(), interval, last_applied_delay, net,
                                env_peak, opt_env_attack(), opt_env_release(),
                                opt_abs_headroom(), delay);
                } else {
                /* v9: track the ABSOLUTE net render time with a fast EMA.
                 * delay = net_ema * gain + headroom, clamped to [base, max]. */
                if (ema_net == 0.0) ema_net = (double)net;
                else ema_net = ema_net * (1.0 - opt_abs_alpha())
                             + (double)net * opt_abs_alpha();
                delay = (long)(ema_net * opt_adaptive_gain())
                      + opt_abs_headroom();
                if (ema_net > (double)(base + 2000)) n_heavy_frames++;
                if (delay < base) delay = base;
                if (delay > maxd) delay = maxd;
                n_adaptive_frames++;
                if (opt_debug())
                    logline("[pid %d] ADP9 interval=%ld last=%ld net=%ld ema=%.0f gain=%.2f head=%ld -> delay=%ld\n",
                            getpid(), interval, last_applied_delay, net,
                            ema_net, opt_adaptive_gain(), opt_abs_headroom(), delay);
                }
            } else {
                /* legacy v8: only compensate the excess ABOVE a slow baseline */
                if (ema_baseline == 0.0) ema_baseline = (double)net;
                else ema_baseline = ema_baseline * (1.0 - opt_adaptive_alpha())
                                  + (double)net * opt_adaptive_alpha();

                double excess = (double)net - ema_baseline;
                if (excess > 0.0) {
                    delay = base + (long)(excess * opt_adaptive_gain());
                    n_heavy_frames++;
                }
                if (delay < base) delay = base;
                if (delay > maxd) delay = maxd;

                n_adaptive_frames++;
                if (opt_debug())
                    logline("[pid %d] ADP interval=%ld last=%ld net=%ld base=%.0f excess=%.0f -> delay=%ld\n",
                            getpid(), interval, last_applied_delay, net,
                            ema_baseline, excess, delay);
            }
        }
    }

    /* remember this frame with THIS computed delay for next frame's feedback */
    clock_gettime(CLOCK_MONOTONIC, &last_frame_ts);
    have_last_frame = 1;
    last_applied_delay = delay;
    return delay;
}

static void delay_us(long us)
{
    if (us <= 0) return;
    struct timespec ts;
    ts.tv_sec = us / 1000000L; ts.tv_nsec = (us % 1000000L) * 1000L;
    while (nanosleep(&ts, &ts) == -1 && errno == EINTR) { }
    n_delay_us += (unsigned long)us;
}

/* Strict: the ENTIRE buffer must be a well-formed wayland message stream. */
static int valid_stream(const unsigned char *p, size_t len)
{
    size_t off = 0; int nmsg = 0;
    while (off + 8 <= len) {
        uint16_t sz; memcpy(&sz, p + off + 6, 2);
        if (sz < 8 || (sz & 3) != 0 || (size_t)(off + sz) > len) return 0;
        off += sz; nmsg++;
        if (nmsg > 4096) return 0;
    }
    return off == len && nmsg > 0;
}

/*
 * Process a copied buffer in place (caller passes a mutable copy).
 *  - confirm "wayland" fd from handshake messages seen in the stream
 *  - if confirmed: widen any wl_surface.damage(op2, size24) rect in place
 *  - report whether a plausible commit(op6, size8) occurred (for delay)
 * NEVER changes byte count. Returns number of damage rects rewritten.
 */
static int process(unsigned char *p, size_t len, int fd, int *saw_commit)
{
    if (!valid_stream(p, len)) return 0;
    size_t off = 0; int rewrote = 0; int confirmed = fd_wl[fd];
    int32_t FW = 32767;   /* full-surface-ish positive rect, KWin clips it */

    while (off + 8 <= len) {
        uint32_t id; uint16_t op, sz;
        memcpy(&id, p + off, 4);
        memcpy(&op, p + off + 4, 2);
        memcpy(&sz, p + off + 6, 2);
        const unsigned char *a = p + off + 8;

        /* wl_display.get_registry(id=1,op0) -> confirm */
        if (id == 1 && op == 0) confirmed = 1;
        /* wl_registry.bind(op0, string iface, ...) -> confirm wayland globals */
        if (op == 0) {
            size_t q = 4;
            if (q + 4 <= (size_t)sz - 8) {
                uint32_t slen; memcpy(&slen, a + q, 4); q += 4;
                if (slen > 2 && slen < 64 && q + slen <= (size_t)sz - 8) {
                    char nm[64]; memcpy(nm, a + q, slen); nm[slen-1] = 0;
                    if (!strcmp(nm,"wl_compositor") || !strcmp(nm,"wl_shm") ||
                        !strcmp(nm,"wl_seat") || !strcmp(nm,"wl_registry"))
                        confirmed = 1;
                }
            }
        }
        /* wl_surface.damage(op2): 4x int32 => size exactly 24.
         * On a confirmed wayland fd this is the MOST RELIABLE per-frame signal
         * in Chrome 157 (the op6 commit is frequently flushed separately or
         * not emitted with sz==8). Use it to drive the commit delay. */
        if (confirmed && op == 2 && sz == 24) {
            *saw_commit = 1;   /* frame signal, regardless of damage widening */
            if (opt_damage()) {
                int32_t x,y; memcpy(&x,a,4); memcpy(&y,a+4,4);
                if (x >= 0 && y >= 0) {
                    int32_t zero = 0;
                    memcpy((void*)a,     &zero, 4);
                    memcpy((void*)a + 4, &zero, 4);
                    memcpy((void*)a + 8, &FW, 4);
                    memcpy((void*)a +12, &FW, 4);
                    rewrote++;
                }
            }
        }
        /* plausible commit: op6, size 8 (secondary frame signal) */
        if (op == 6 && confirmed && sz == 8) *saw_commit = 1;
        off += sz;
    }
    if (confirmed && fd < MAX_FDS) fd_wl[fd] = 1;
    if (rewrote) {
        n_damage_rewritten += (unsigned long)rewrote;
        if (opt_debug())
            logline("[pid %d] widened %d damage rect(s) len=%zu fd=%d\n",
                    getpid(), rewrote, len, fd);
    }
    return rewrote;
}

/* For write()/send(): make a mutable copy, process in place, send via real
 * function with ORIGINAL length. Returns real's result. */
static ssize_t emit(int fd, const void *buf, size_t len,
                    ssize_t (*real)(int, const void *, size_t))
{
    int force = getenv("WIRE_FORCE_FD") != NULL;
    if (!force && !fd_wl[fd] && !valid_stream((const unsigned char*)buf, len))
        return real(fd, buf, len);
    unsigned char *copy = (unsigned char *)malloc(len);
    if (!copy) return real(fd, buf, len);
    memcpy(copy, buf, len);
    int saw_commit = 0;
    process(copy, len, fd, &saw_commit);
    if (saw_commit && fd_wl[fd]) {
        long d = frame_delay_us();
        delay_us(d); n_commit_seen++;
        if (opt_debug()) logline("[pid %d] DELAY %ldus fd=%d len=%zu (frame signal)\n",
                                 getpid(), d, fd, len);
    }
    ssize_t r = real(fd, copy, len);   /* SAME length; real preserves ancillary for send */
    free(copy);
    if (r >= 0) n_flush_seen++;
    return r;
}

ssize_t write(int fd, const void *buf, size_t count)
{
    init_real();
    if (!real_write || !buf || count < 8 || count > (1u<<20))
        return real_write ? real_write(fd, buf, count) : (ssize_t)syscall(SYS_write, fd, buf, count);
    return emit(fd, buf, count, real_write);
}

ssize_t send(int fd, const void *buf, size_t len, int flags)
{
    init_real();
    if (flags != 0 || !real_write || !buf || len < 8 || len > (1u<<20))
        return real_send ? real_send(fd, buf, len, flags) : (ssize_t)syscall(SYS_sendto, fd, buf, len, flags, NULL, 0);
    /* flags==0: write() and send() are equivalent on a socket; use real_write
     * through emit so the helper keeps a uniform 3-arg signature. */
    return emit(fd, buf, len, real_write);
}

ssize_t writev(int fd, const struct iovec *iov, int iovcnt)
{
    init_real();
    if (!real_writev || iovcnt <= 0) return real_writev ? real_writev(fd, iov, iovcnt) : (ssize_t)syscall(SYS_writev, fd, iov, iovcnt);
    size_t total = 0; for (int i=0;i<iovcnt;i++) total += iov[i].iov_len;
    if (total < 8 || total > (1u<<20)) return real_writev(fd, iov, iovcnt);
    unsigned char *flat = (unsigned char*)malloc(total);
    if (!flat) return real_writev(fd, iov, iovcnt);
    size_t o=0; for (int i=0;i<iovcnt;i++){ memcpy(flat+o,iov[i].iov_base,iov[i].iov_len); o+=iov[i].iov_len; }
    int saw_commit=0;
    if (fd_wl[fd] || valid_stream(flat,total)) process(flat,total,fd,&saw_commit);
    if (saw_commit && fd_wl[fd]) {
        long d = frame_delay_us();
        delay_us(d); n_commit_seen++;
        if (opt_debug()) logline("[pid %d] DELAY %ldus fd=%d len=%zu (writev)\n",
                                 getpid(), d, fd, total);
    }
    ssize_t r = real_writev(fd, iov, iovcnt);   /* original iov, but we modified payload in place */
    free(flat);
    return r;
}

ssize_t sendmsg(int fd, const struct msghdr *msg, int flags)
{
    init_real();
    if (!real_sendmsg || !msg || msg->msg_iovlen <= 0 || (flags & MSG_OOB))
        return real_sendmsg ? real_sendmsg(fd, msg, flags) : (ssize_t)syscall(SYS_sendmsg, fd, msg, flags);
    size_t total = 0; for (size_t i=0;i<msg->msg_iovlen;i++) total += msg->msg_iov[i].iov_len;
    if (total < 8 || total > (1u<<20)) return real_sendmsg(fd, msg, flags);
    /* modify the caller's iov payload in place (length unchanged) */
    int saw_commit=0;
    int force = getenv("WIRE_FORCE_FD")!=NULL;
    if (force || fd_wl[fd] || valid_stream((const unsigned char*)msg->msg_iov[0].iov_base,total)) {
        /* flatten only if multiple iov; else process directly */
        if (msg->msg_iovlen == 1)
            process((unsigned char*)msg->msg_iov[0].iov_base, msg->msg_iov[0].iov_len, fd, &saw_commit);
        else {
            unsigned char *flat=(unsigned char*)malloc(total);
            if (flat) {
                size_t o=0; for(size_t i=0;i<msg->msg_iovlen;i++){memcpy(flat+o,msg->msg_iov[i].iov_base,msg->msg_iov[i].iov_len);o+=msg->msg_iov[i].iov_len;}
                process(flat,total,fd,&saw_commit);
                o=0; for(size_t i=0;i<msg->msg_iovlen;i++){memcpy(msg->msg_iov[i].iov_base,flat+o,msg->msg_iov[i].iov_len);o+=msg->msg_iov[i].iov_len;}
                free(flat);
            }
        }
    }
    if (saw_commit && fd_wl[fd]) {
        long d = frame_delay_us();
        delay_us(d); n_commit_seen++;
        if (opt_debug()) logline("[pid %d] DELAY %ldus fd=%d len=%zu (sendmsg)\n",
                                 getpid(), d, fd, total);
    }
    ssize_t r = real_sendmsg(fd, msg, flags);   /* original msghdr: ancillary preserved */
    if (r >= 0) n_flush_seen++;
    return r;
}

__attribute__((constructor)) static void wire_loaded(void)
{
    logline("=== wire-commit-shim v12 pid=%d damage=%d delay=%ld adaptive=%d "
            "mode=%s max=%ld gain=%.2f head=%ld env=%d atk=%.2f rel=%.2f "
            "lock=%d k=%d T=%ld adapt=%d kmin=%d kmax=%d up=%.2f down=%.2f "
            "atk=%.2f rel=%.2f hold=%d ===\n",
            getpid(), opt_damage(), opt_delay_us(), opt_adaptive(),
            opt_lock() ? "vsync-lock" : (opt_env() ? "envelope" : (opt_mode_absolute() ? "absolute" : "legacy")),
            opt_adaptive_max(), opt_adaptive_gain(), opt_abs_headroom(),
            opt_env(), opt_env_attack(), opt_env_release(),
            opt_lock(), opt_lock_k(), opt_lock_T(),
            opt_lock_adapt(), opt_lock_k_min(), opt_lock_k_max(),
            opt_lock_up_ratio(), opt_lock_down_ratio(),
            opt_lock_env_attack(), opt_lock_env_release(), opt_lock_hold());
}
__attribute__((destructor)) static void wire_done(void)
{
    logline("--- pid=%d flush=%lu commits=%lu rewrote=%lu delay_us=%lu "
            "adaptive_frames=%lu heavy=%lu k_up=%lu k_down=%lu final_k=%d "
            "hybrid=%d hybrid_locked=%lu hybrid_lost=%lu hybrid_maxk=%d ---\n",
            getpid(), n_flush_seen, n_commit_seen, n_damage_rewritten, n_delay_us,
            n_adaptive_frames, n_heavy_frames, n_k_up, n_k_down, cur_k,
            opt_lock_hybrid(), n_hybrid_locked, n_hybrid_lost, n_hybrid_maxk);
}
