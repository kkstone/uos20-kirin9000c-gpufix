#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* wl_pointer_add_listener() is a static inline in the Wayland header; rename
 * it while including so our interposing symbol below can use the real name. */
#define wl_pointer_add_listener wayland_header_wl_pointer_add_listener
#include <wayland-client.h>
#undef wl_pointer_add_listener

/*
 * pointer_guard.so - fill NULL wl_pointer event handlers for Chrome on the
 * HUAWEI KWin / libwayland 1.26 stack.  ZERO side effects on input behaviour.
 *
 * Root cause of "Chrome crashes on maximize":
 *   HUAWEI's libwayland 1.26 adds private wl_pointer events. Counting events
 *   only: 0 enter, 1 leave, 2 motion, 3 button, 4 axis, 5 frame, 6 axis_source,
 *   7 axis_stop, 8 axis_discrete, 9 axis_value120, 10 axis_relative_direction,
 *   11 warp.  KWin emits a warp (opcode 11) during window management
 *   (maximize/restore/resize).  Chrome 157 was built against an older header
 *   whose wl_pointer_listener has no warp slot, so libwayland reads past the
 *   end of Chrome's listener array, finds implementation[11] == NULL and
 *   aborts: "libwayland: listener function for opcode 11 of wl_pointer is NULL"
 *   Firefox never crashes because its wheel_shim wraps the pointer listener
 *   and fills EVERY slot (incl. warp) with a non-NULL function.
 *
 * This shim wraps Chrome's pointer listener with a FULL 12-handler array we
 * allocate ourselves (using the system's complete wayland header). Each
 * wrapper is pure pass-through: if Chrome's original handler for that event
 * is non-NULL we call it with the original data; if it is NULL (or absent)
 * we call a no-op.  Nothing is rewritten, dropped or scaled - scroll, cursor
 * and click behaviour are 100% unchanged.  Unlike wheel_shim there is no
 * WHEEL->CONTINUOUS rewrite and no discrete/value120 dropping.
 *
 * libwayland retains the implementation pointer, so the wrapped listener and
 * context are heap allocated and intentionally never freed (one per pointer).
 */
typedef int (*add_listener_t)(struct wl_pointer *,
                              const struct wl_pointer_listener *, void *);
typedef int (*proxy_add_listener_t)(struct wl_proxy *, void (**)(void), void *);

struct guard_ctx {
    const struct wl_pointer_listener *orig;
    void *data;
    struct wl_pointer_listener wrapped;
};

static int debug_enabled(void) {
    static int cached = -1;
    if (cached < 0) {
        const char *e = getenv("POINTER_GUARD_DEBUG");
        cached = (e && e[0] && strcmp(e, "0") != 0) ? 1 : 0;
    }
    return cached;
}

__attribute__((constructor))
static void guard_loaded(void) {
    if (debug_enabled())
        fprintf(stderr, "[pointer_guard] loaded\n");
}

static struct guard_ctx *ctx_of(void *data) {
    return (struct guard_ctx *)data;
}

/* Pure pass-through wrappers: call original if present, else no-op. */
static void w_enter(void *d, struct wl_pointer *p, uint32_t s,
                    struct wl_surface *sf, wl_fixed_t x, wl_fixed_t y) {
    struct guard_ctx *c = ctx_of(d);
    if (c->orig->enter) c->orig->enter(c->data, p, s, sf, x, y);
}
static void w_leave(void *d, struct wl_pointer *p, uint32_t s,
                    struct wl_surface *sf) {
    struct guard_ctx *c = ctx_of(d);
    if (c->orig->leave) c->orig->leave(c->data, p, s, sf);
}
static void w_motion(void *d, struct wl_pointer *p, uint32_t t,
                     wl_fixed_t x, wl_fixed_t y) {
    struct guard_ctx *c = ctx_of(d);
    if (c->orig->motion) c->orig->motion(c->data, p, t, x, y);
}
static void w_button(void *d, struct wl_pointer *p, uint32_t s,
                     uint32_t t, uint32_t b, uint32_t state) {
    struct guard_ctx *c = ctx_of(d);
    if (c->orig->button) c->orig->button(c->data, p, s, t, b, state);
}
static void w_axis(void *d, struct wl_pointer *p, uint32_t t,
                   uint32_t axis, wl_fixed_t value) {
    struct guard_ctx *c = ctx_of(d);
    if (c->orig->axis) c->orig->axis(c->data, p, t, axis, value);
}
static void w_frame(void *d, struct wl_pointer *p) {
    struct guard_ctx *c = ctx_of(d);
    if (c->orig->frame) c->orig->frame(c->data, p);
}
static void w_axis_source(void *d, struct wl_pointer *p, uint32_t src) {
    struct guard_ctx *c = ctx_of(d);
    if (c->orig->axis_source) c->orig->axis_source(c->data, p, src);
}
static void w_axis_stop(void *d, struct wl_pointer *p, uint32_t t, uint32_t axis) {
    struct guard_ctx *c = ctx_of(d);
    if (c->orig->axis_stop) c->orig->axis_stop(c->data, p, t, axis);
}
static void w_axis_discrete(void *d, struct wl_pointer *p,
                            uint32_t axis, int32_t discrete) {
    struct guard_ctx *c = ctx_of(d);
    if (c->orig->axis_discrete) c->orig->axis_discrete(c->data, p, axis, discrete);
}
static void w_axis_value120(void *d, struct wl_pointer *p,
                            uint32_t axis, int32_t v) {
    struct guard_ctx *c = ctx_of(d);
    if (c->orig->axis_value120) c->orig->axis_value120(c->data, p, axis, v);
}
static void w_axis_relative_direction(void *d, struct wl_pointer *p,
                                      uint32_t axis, uint32_t dir) {
    struct guard_ctx *c = ctx_of(d);
    if (c->orig->axis_relative_direction)
        c->orig->axis_relative_direction(c->data, p, axis, dir);
}
static void w_warp(void *d, struct wl_pointer *p, wl_fixed_t x, wl_fixed_t y) {
    struct guard_ctx *c = ctx_of(d);
    if (c->orig->warp) c->orig->warp(c->data, p, x, y);
}

static struct guard_ctx *make_guard(const struct wl_pointer_listener *orig,
                                    void *data, const char *tag) {
    struct guard_ctx *c = calloc(1, sizeof(*c));
    if (!c) return NULL;
    c->orig = orig;
    c->data = data;
    /* Fill our OWN complete array with non-NULL wrappers - never copy orig's
     * (possibly shorter) struct, which would read out of bounds. */
    c->wrapped.enter = w_enter;
    c->wrapped.leave = w_leave;
    c->wrapped.motion = w_motion;
    c->wrapped.button = w_button;
    c->wrapped.axis = w_axis;
    c->wrapped.frame = w_frame;
    c->wrapped.axis_source = w_axis_source;
    c->wrapped.axis_stop = w_axis_stop;
    c->wrapped.axis_discrete = w_axis_discrete;
    c->wrapped.axis_value120 = w_axis_value120;
    c->wrapped.axis_relative_direction = w_axis_relative_direction;
    c->wrapped.warp = w_warp;
    if (debug_enabled())
        fprintf(stderr, "[pointer_guard] %s wrapped listener %p (12 handlers)\n",
                tag, (void *)orig);
    return c;
}

int wl_proxy_add_listener(struct wl_proxy *proxy, void (**implementation)(void),
                          void *data) {
    static proxy_add_listener_t real_add = NULL;
    if (!real_add)
        real_add = (proxy_add_listener_t)dlsym(RTLD_NEXT, "wl_proxy_add_listener");
    if (!real_add) return -1;
    if (wl_proxy_get_interface(proxy) != &wl_pointer_interface || !implementation)
        return real_add(proxy, implementation, data);

    struct guard_ctx *c = make_guard(
        (const struct wl_pointer_listener *)implementation, data, "proxy");
    if (!c) return real_add(proxy, implementation, data);
    return real_add(proxy, (void (**)(void))&c->wrapped, c);
}

int wl_pointer_add_listener(struct wl_pointer *p,
                            const struct wl_pointer_listener *listener,
                            void *data) {
    static add_listener_t real_add = NULL;
    if (!real_add)
        real_add = (add_listener_t)dlsym(RTLD_NEXT, "wl_pointer_add_listener");
    if (!listener || !real_add) return real_add(p, listener, data);

    struct guard_ctx *c = make_guard(listener, data, "typed");
    if (!c) return real_add(p, listener, data);
    return real_add(p, &c->wrapped, c);
}
