/*
 * cursor-wire-shim.so -- fix Chrome 157 Wayland cursor size at the wire level
 *
 * Chrome's bundled libGLESv2.so statically embeds its own libwayland-client
 * and calls its own marshal functions directly, so LD_PRELOAD hooks on
 * wl_proxy_marshal_* cannot reach the cursor requests. Both copies, however,
 * send bytes to the compositor through write(2) on the Wayland socket.
 *
 * This shim parses outgoing Wayland messages, learns object ids for
 * wl_compositor.create_surface and wl_seat.get_pointer, records the surface
 * used by wl_pointer.set_cursor, and rewrites that surface's
 * wl_surface.set_buffer_scale from DSF (2) to 1 before the bytes go out.
 * Chrome's 24*DSF px cursor buffer is then displayed at native size instead
 * of being halved into a 24dp logical cursor. Hotspot stays correct because
 * it is tip-relative. No Chrome binary patching.
 */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdarg.h>
#include <sys/uio.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/socket.h>

#define MAX_IDS 256

static ssize_t (*real_write)(int, const void *, size_t);
static ssize_t (*real_writev)(int, const struct iovec *, int);
static ssize_t (*real_sendmsg)(int, const struct msghdr *, int);
static ssize_t (*real_send)(int, const void *, size_t, int);
static int ids_ready;
static uint32_t registries[MAX_IDS]; static int n_reg;
static uint32_t seats[MAX_IDS]; static int n_seat;
static uint32_t compositors[MAX_IDS]; static int n_comp;
static uint32_t surfaces[MAX_IDS]; static int n_surf;
static uint32_t pointers[MAX_IDS]; static int n_ptr;
static uint32_t shms[MAX_IDS]; static int n_shm;
static uint32_t pools[MAX_IDS]; static int n_pool;
static uint32_t buffers[MAX_IDS]; static int n_buf;
static uint32_t buf_wh[MAX_IDS];
static uint32_t cursors[MAX_IDS]; static int n_cur;

/* Release build: logging is OFF by default and creates NO file.
 * Enable with CURSOR_SHIM_DEBUG=1. */
static int debug_enabled(void)
{
    static int v = -1;
    if (v < 0) {
        const char *e = getenv("CURSOR_SHIM_DEBUG");
        v = (e && e[0] && strcmp(e, "0") != 0) ? 1 : 0;
    }
    return v;
}

static void logline(const char *fmt, ...)
{
    static FILE *fp;
    va_list ap;
    if (!debug_enabled()) return;
    if (!fp) {
        fp = fopen("/tmp/cursor-wire-shim.log", "a");
        if (fp) setvbuf(fp, NULL, _IOLBF, 0);
    }
    if (!fp) return;
    va_start(ap, fmt);
    vfprintf(fp, fmt, ap);
    va_end(ap);
}

static void add_id(uint32_t *arr, int *n, uint32_t id)
{
    if (*n >= MAX_IDS) return;
    for (int i = 0; i < *n; i++) if (arr[i] == id) return;
    arr[(*n)++] = id;
}

static int has_id(uint32_t *arr, int n, uint32_t id)
{
    for (int i = 0; i < n; i++) if (arr[i] == id) return 1;
    return 0;
}

static void init_real(void)
{
    if (ids_ready) return;
    ids_ready = 1;
    real_write = (ssize_t (*)(int, const void *, size_t))dlsym(RTLD_NEXT, "write");
    real_writev = (ssize_t (*)(int, const struct iovec *, int))dlsym(RTLD_NEXT, "writev");
    real_sendmsg = (ssize_t (*)(int, const struct msghdr *, int))dlsym(RTLD_NEXT, "sendmsg");
    real_send = (ssize_t (*)(int, const void *, size_t, int))dlsym(RTLD_NEXT, "send");
    add_id(registries, &n_reg, 2); /* default wl_registry id in most clients */
}

/* Pass 1: learn object ids. Pass 2: rewrite cursor set_buffer_scale. */
static int scan(const unsigned char *p, size_t len, int patch)
{
    size_t off = 0;
    int changed = 0;
    while (off + 8 <= len) {
        uint32_t id;
        uint16_t op, sz;
        memcpy(&id, p + off, 4);
        memcpy(&op, p + off + 4, 2);
        memcpy(&sz, p + off + 6, 2);
        if (sz < 8 || (size_t)(off + sz) > len) break;
        const unsigned char *a = p + off + 8;

        /* wl_display.get_registry(op0): uint new_id */
        if (id == 1 && op == 0 && sz >= 12) {
            uint32_t nid; memcpy(&nid, a, 4);
            add_id(registries, &n_reg, nid);
        }
        /* wl_registry.bind(op0): uint name, string iface, uint ver, uint new_id */
        if (has_id(registries, n_reg, id) && op == 0) {
            size_t q = 4;
            if (q + 4 <= (size_t)sz - 8) {
                uint32_t slen; memcpy(&slen, a + q, 4);
                q += 4;
                if (slen > 0 && slen < 128 && q + slen <= (size_t)sz - 8) {
                    char name[128];
                    memcpy(name, a + q, slen);
                    name[slen - 1] = 0;
                    q += (slen + 3) & ~3u;
                    if (q + 8 <= (size_t)sz - 8) {
                        uint32_t nid; memcpy(&nid, a + q + 4, 4);
                        if (strcmp(name, "wl_compositor") == 0) add_id(compositors, &n_comp, nid);
                        else if (strcmp(name, "wl_seat") == 0) add_id(seats, &n_seat, nid);
                        else if (strcmp(name, "wl_shm") == 0) add_id(shms, &n_shm, nid);
                    }
                }
            }
        }
        /* wl_shm.create_pool(op0): uint new_id, fd, int size */
        if (has_id(shms, n_shm, id) && op == 0 && sz >= 20) {
            uint32_t nid; memcpy(&nid, a, 4);
            add_id(pools, &n_pool, nid);
        }
        /* wl_shm_pool.create_buffer(op0): uint new_id, int offset, int width, int height, int stride, uint format */
        if (has_id(pools, n_pool, id) && op == 0 && sz >= 28) {
            uint32_t nid; memcpy(&nid, a, 4);
            int32_t w, h; memcpy(&w, a + 8, 4); memcpy(&h, a + 12, 4);
            if (n_buf < MAX_IDS) {
                buffers[n_buf] = nid;
                buf_wh[n_buf] = ((uint32_t)(uint16_t)w << 16) | (uint16_t)h;
                n_buf++;
            }
        }
        /* wl_compositor.create_surface(op0): uint new_id */
        if (has_id(compositors, n_comp, id) && op == 0 && sz >= 12) {
            uint32_t nid; memcpy(&nid, a, 4);
            add_id(surfaces, &n_surf, nid);
        }
        /* wl_seat.get_pointer(op0): uint new_id */
        if (has_id(seats, n_seat, id) && op == 0 && sz >= 12) {
            uint32_t nid; memcpy(&nid, a, 4);
            add_id(pointers, &n_ptr, nid);
        }
        /* wl_surface.attach(op1): object buffer, int x, int y */
        if (has_id(surfaces, n_surf, id) && op == 1 && sz >= 20) {
            uint32_t bid; memcpy(&bid, a, 4);
            for (int i = 0; i < n_buf; i++) {
                if (buffers[i] == bid) {
                    int w = (int)(buf_wh[i] >> 16), h = (int)(buf_wh[i] & 0xffff);
                    if (w > 0 && h > 0 && w <= 96 && h <= 96) {
                        add_id(cursors, &n_cur, id);
                        logline("[pid %d] cursor surface#%u from %dx%d buffer\n", getpid(), id, w, h);
                    }
                    break;
                }
            }
        }
        /* wl_pointer.set_cursor(op0): uint serial, object surface, int hx, int hy */
        if (has_id(pointers, n_ptr, id) && op == 0 && sz >= 24) {
            uint32_t surf; memcpy(&surf, a + 4, 4);
            add_id(cursors, &n_cur, surf);
        }
        /* wl_surface.set_buffer_scale(op8): int scale */
        if (patch && has_id(cursors, n_cur, id) && op == 8 && sz >= 12) {
            int32_t scale;
            memcpy(&scale, a, 4);
            if (scale != 1) {
                int32_t one = 1;
                memcpy((void *)a, &one, 4);
                changed++;
                logline("[pid %d] patched cursor surface#%u set_buffer_scale %d -> 1\n",
                        getpid(), id, scale);
            }
        }
        off += sz;
    }
    return changed;
}

ssize_t write(int fd, const void *buf, size_t count)
{
    init_real();
    if (real_write && count >= 8 && count <= 1 << 20 && buf) {
        const unsigned char *p = buf;
        scan(p, count, 0);
        if (n_cur > 0) {
            unsigned char *copy = malloc(count);
            if (copy) {
                memcpy(copy, p, count);
                if (scan(copy, count, 1) > 0) {
                    ssize_t r = syscall(SYS_write, fd, copy, count);
                    free(copy);
                    return r;
                }
                free(copy);
            }
        }
    }
    return real_write ? real_write(fd, buf, count) :
        (ssize_t)syscall(SYS_write, fd, buf, count);
}

ssize_t writev(int fd, const struct iovec *iov, int iovcnt)
{
    init_real();
    if (real_writev && iovcnt > 0) {
        size_t total = 0;
        for (int i = 0; i < iovcnt; i++) total += iov[i].iov_len;
        if (total >= 8 && total <= 1 << 20) {
            unsigned char *flat = malloc(total);
            if (flat) {
                size_t o = 0;
                for (int i = 0; i < iovcnt; i++) {
                    memcpy(flat + o, iov[i].iov_base, iov[i].iov_len);
                    o += iov[i].iov_len;
                }
                scan(flat, total, 0);
                if (n_cur > 0 && scan(flat, total, 1) > 0) {
                    ssize_t r = syscall(SYS_write, fd, flat, total);
                    free(flat);
                    return r;
                }
                free(flat);
            }
        }
    }
    return real_writev ? real_writev(fd, iov, iovcnt) :
        (ssize_t)syscall(SYS_writev, fd, iov, iovcnt);
}


/* Wayland socket flush uses sendmsg(MSG_NOSIGNAL) on Linux. */
ssize_t sendmsg(int fd, const struct msghdr *msg, int flags)
{
    init_real();
    if (real_sendmsg && msg && msg->msg_iovlen > 0) {
        size_t total = 0;
        for (int i = 0; i < msg->msg_iovlen; i++) total += msg->msg_iov[i].iov_len;
        if (total >= 8 && total <= 1 << 20) {
            unsigned char *flat = malloc(total);
            if (flat) {
                size_t o = 0;
                for (int i = 0; i < msg->msg_iovlen; i++) {
                    memcpy(flat + o, msg->msg_iov[i].iov_base, msg->msg_iov[i].iov_len);
                    o += msg->msg_iov[i].iov_len;
                }
                scan(flat, total, 0);
                if (n_cur > 0 && scan(flat, total, 1) > 0) {
                    ssize_t r = syscall(SYS_sendmsg, fd, &(struct msghdr){
                        .msg_iov = &(struct iovec){ .iov_base = flat, .iov_len = total },
                        .msg_iovlen = 1
                    }, flags);
                    free(flat);
                    return r;
                }
                free(flat);
            }
        }
    }
    return real_sendmsg ? real_sendmsg(fd, msg, flags) :
        (ssize_t)syscall(SYS_sendmsg, fd, msg, flags);
}

ssize_t send(int fd, const void *buf, size_t len, int flags)
{
    init_real();
    if (real_send && buf && len >= 8 && len <= 1 << 20) {
        const unsigned char *p = buf;
        scan(p, len, 0);
        if (n_cur > 0) {
            unsigned char *copy = malloc(len);
            if (copy) {
                memcpy(copy, p, len);
                if (scan(copy, len, 1) > 0) {
                    ssize_t r = syscall(SYS_sendto, fd, copy, len, flags, NULL, 0);
                    free(copy);
                    return r;
                }
                free(copy);
            }
        }
    }
    return real_send ? real_send(fd, buf, len, flags) :
        (ssize_t)syscall(SYS_sendto, fd, buf, len, flags, NULL, 0);
}
