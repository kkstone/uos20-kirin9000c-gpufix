/*
 * gbm-hw-shim.so -- enable Chrome 157 hardware compositing on UOS 20 /
 * Kirin 9000c / Maleoon 910 (HUAWEI libGFX_hisi GBM/EGL).
 *
 * ROOT CAUSE (verified with real stderr):
 *   Chrome's GbmPixmapWayland::InitializeBuffer() calls
 *   gbm_bo_create(w,h,format, flags=Scanout|Rendering|Texturing = 37) for
 *   the real window pixmap. HUAWEI GBM rejects those flags for every RGB
 *   format -> gbm_pixmap_wayland.cc:104 "Cannot create bo" -> GPU process
 *   crash loop -> Chrome silently degrades to software compositing.
 *
 *   HUAWEI GBM CAN create the same buffer via
 *   gbm_bo_create_with_modifiers(..., modifier=0x0900000000000002), which
 *   is the only modifier KWin advertises for XR24/AR24 (verified with
 *   wl-dmabuf-query.c and gbm-fd-test.c).
 *
 * ABI ISSUES BRIDGED:
 *   1. Chromium resolves gbm_* via dlsym(handle,...) after dlopen, so plain
 *      LD_PRELOAD symbol interposition is bypassed. We hook dlsym().
 *   2. gbm_bo_get_fd_for_plane is a WEAK import HUAWEI doesn't export ->
 *      drmPrimeHandleToFD fallback -> EBADF flood. We supply it via
 *      HUAWEI's gbm_bo_get_fd().
 *   3. gbm_bo_get_modifier on HUAWEI bo returns 0; we report KWin's modifier
 *      so Chrome's gbm_bo_import carries a modifier KWin accepts.
 *   4. gbm_import_fd_modifier_data: Chrome writes modifier at byte 56,
 *      HUAWEI reads at byte 64. We write to BOTH in a local copy.
 *   5. JITTER ROOT CAUSE: HUAWEI reports stride=0 / stride_for_plane=32 for
 *      HISI-modifier bos (correct is width*4). Wrong stride -> every row
 *      sampled at the wrong offset -> moving video/WebGL jitters. We repair
 *      implausible strides to width*4. See repair_stride().
 *
 * Toggles: HISI_GBM_SHIM=0 (all off), HISI_GBM_SHIM_DEBUG=1,
 *          HISI_GBM_MODIFIER=0x..., HISI_GBM_CREATE_FIX=0,
 *          HISI_GBM_PLANE_FD=0, HISI_GBM_REPORT_MODIFIER=0,
 *          HISI_GBM_IMPORT_FIX=0, HISI_GBM_STRIDE_FIX=0
 */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <sys/stat.h>

typedef struct gbm_bo gbm_bo;
typedef struct gbm_device gbm_device;
union gbm_bo_handle { void *ptr; uint32_t u32; };

typedef int (*fn_plane_fd)(gbm_bo *, int);
typedef int (*fn_gbm_bo_get_fd)(gbm_bo *);
typedef uint64_t (*fn_gbm_bo_get_modifier)(gbm_bo *);
typedef gbm_device *(*fn_gbm_bo_get_device)(gbm_bo *);
typedef int (*fn_gbm_device_get_fd)(gbm_device *);
typedef union gbm_bo_handle (*fn_gbm_bo_get_handle_for_plane)(gbm_bo *, int);
typedef int (*fn_drm_prime)(int, uint32_t, uint32_t, int *);
typedef gbm_bo *(*fn_gbm_bo_create)(gbm_device *, uint32_t, uint32_t,
                                    uint32_t, uint32_t);
typedef gbm_bo *(*fn_gbm_bo_create_with_modifiers)(gbm_device *, uint32_t,
        uint32_t, uint32_t, const uint64_t *, uint32_t);
typedef gbm_bo *(*fn_gbm_bo_import)(gbm_device *, uint32_t, void *, uint32_t);
typedef uint32_t (*fn_gbm_bo_get_stride)(gbm_bo *);
typedef uint32_t (*fn_gbm_bo_get_stride_for_plane)(gbm_bo *, int);
typedef uint32_t (*fn_gbm_bo_get_width)(gbm_bo *);

/* ---- VAAPI version spoof (merged: only ONE dlsym hook allowed) ------- */
typedef int VAStatus;
typedef void *VADisplay;
#define VA_STATUS_SUCCESS 0
static VAStatus (*captured_real_vaInitialize)(VADisplay, int *, int *) = NULL;
VAStatus vaInitialize(VADisplay dpy, int *major, int *minor);

#define KWIN_MOD_DEFAULT 0x0900000000000002ULL
#define GBM_BO_IMPORT_FD_MODIFIER 0x5504

/* Resolve the REAL dlsym via a versioned symbol (proven in vaapi spoof).
 * __libc_dlsym(RTLD_NEXT, ...) segfaults on this glibc. */
static void *(*real_dlsym_fn(void))(void *, const char *) {
    static void *(*r)(void *, const char *) = NULL;
    if (!r) r = (void *(*)(void *, const char *))
            dlvsym(RTLD_NEXT, "dlsym", "GLIBC_2.17");
    return r;
}
static void *real_sym(const char *name) {
    void *(*rd)(void *, const char *) = real_dlsym_fn();
    return rd ? rd(RTLD_NEXT, name) : NULL;
}

static void finish_debug_dump(void);   /* 1.0.14: dump hit counters at exit */

/* Strict boolean env: only "1" enables, "0" disables, anything else keeps
 * the default. getenv() mere presence is NOT enough - "GPU_FINISH_DEBUG=0"
 * must mean OFF, otherwise a user who disables it still gets a log file. */
static int env_flag(const char *name, int def_on) {
    const char *v = getenv(name);
    if (!v) return def_on;
    if (strcmp(v, "0") == 0) return 0;
    if (strcmp(v, "1") == 0) return 1;
    return def_on;
}
static int debug_enabled(void) { return env_flag("HISI_GBM_SHIM_DEBUG", 0); }

__attribute__((constructor)) static void gbm_hw_loaded(void) {
    /* 1.0.14 FIX: 1.0.13 defined finish_debug_dump() but NEVER registered it
     * via atexit, so GPU_FINISH_DEBUG=1 produced no log at all. Register now. */
    if (env_flag("GPU_FINISH_DEBUG", 0)) atexit(finish_debug_dump);
    /* Diagnostic trace is OPT-IN only. Writing one line per process to a
     * shared file and, more importantly, fprintf(stderr) on every create /
     * import / prime call in the render hot path BLOCKS on terminal I/O when
     * Chrome is launched from a TTY. That synchronous logging stalled GPU
     * compositing and made even static pages (chrome://gpu) lag while
     * scrolling. Default off; enable with HISI_GBM_SHIM_DEBUG=1. */
    if (env_flag("HISI_GBM_SHIM_DEBUG", 0)) {
        FILE *f = fopen("/tmp/gbm-hw-loaded.txt", "a");
        if (f) {
            fprintf(f, "pid=%d debug=%s shim=%s ldpreload=%s\n", (int)getpid(),
                    getenv("HISI_GBM_SHIM_DEBUG") ?: "NULL",
                    getenv("HISI_GBM_SHIM") ?: "NULL",
                    getenv("LD_PRELOAD") ?: "NULL");
            fclose(f);
        }
    }
    /* Chrome's zygote scrubs these; restore VAAPI env in every child. */
    if (!getenv("LIBVA_DRIVER_NAME")) setenv("LIBVA_DRIVER_NAME", "vacore", 1);
    if (!getenv("LIBVA_DRIVERS_PATH")) setenv("LIBVA_DRIVERS_PATH", "/usr/lib", 1);
    setenv("LIBVA_DRI3_DISABLE", "1", 1);
    /* NOTE: allow_rgb10_configs is intentionally NOT set. It is a stale knob
     * that only emits "default value overridden by environment" noise. */
}

/* =====================================================================
 * GPU-SIDE TRUE SYNC (方案 A, v1.0.15): glFinish() at dma-buf export.
 *
 * Why: the wire-damage-shim only SLEEPS on the Wayland byte stream to
 * "guess" when the GPU finished writing the dma-buf. Frame cost varies
 * so a sleep can never line up -> residual jelly. Firefox never has this
 * problem: its HUAWEI native EGL/WAYLAND path (0x31D8) keeps buffer
 * creation + attach + swap inside one driver with implicit correct sync.
 * Chrome's ANGLE->GL->GBM dma-buf export path loses that sync.
 *
 * ROAD CORRECTION (v1.0.13/14 were wrong): hooking eglSwapBuffers NEVER
 * fired in real Chrome — swap=0 in all 41 child processes; ANGLE binds it
 * internally, bypassing both our dlsym hook and PLT preloading. The REAL
 * per-frame, context-bearing point is gbm_bo_get_fd_for_plane(): verified
 * GETFD current_ctx=YES on the GPU render thread. glFinish() there blocks
 * until this frame's GL commands retire, BEFORE the fd is handed to Wayland
 * and wl_surface.commit is emitted -> KWin cannot scan a stale buffer.
 * Needs NO EGL_ANDROID_native_fence_fd (HUAWEI lacks) and NO syncobj
 * (KWin 5.27 lacks). Throttled to one glFinish per 2ms window.
 *
 * MUST live in this .so: env.sh allows only ONE dlsym hook (a second one
 * conflicts), so all interception is merged here.
 *
 * Toggles:
 *   GPU_FINISH_SYNC=1   enable (default 1; =0 restores old behaviour)
 *   GPU_FINISH_DEBUG=1  log hit counts to /tmp/gpu-finish-shim.log
 * ===================================================================== */
typedef void *EGLDisplay;
typedef void *EGLSurface;
typedef unsigned char EGLBoolean;
typedef EGLBoolean (*fn_eglSwapBuffers)(EGLDisplay, EGLSurface);
typedef void (*fn_glFinish)(void);

static fn_eglSwapBuffers captured_real_eglSwapBuffers = NULL;
static fn_glFinish       captured_real_glFinish = NULL;
static unsigned long n_swap_calls = 0, n_finish_calls = 0;
static unsigned long n_swap_first_logged = 0;
static int gl_finish_available = -1;   /* -1 unknown, 0 unavailable, 1 ok */
/* 1.0.14-diag: dma-buf export hook hit counters */
static unsigned long n_getfd_calls = 0, n_getfd_with_ctx = 0, n_getfd_first_logged = 0;

static int finish_sync_enabled(void) { return env_flag("GPU_FINISH_SYNC", 1); }

/* Resolve glFinish with 3 fallbacks. RTLD_NEXT alone (1.0.13) fails when
 * ANGLE's libGLESv2 is loaded RTLD_LOCAL — the likely reason 1.0.13 "did
 * nothing": the swap hook fired but glFinish was never actually called. */
static fn_glFinish resolve_glFinish(void) {
    fn_glFinish fin = captured_real_glFinish;
    if (!fin) fin = (fn_glFinish)real_sym("glFinish");
    if (!fin) fin = (fn_glFinish)dlsym(RTLD_DEFAULT, "glFinish");
    return fin;
}

/* One-shot log on the very first swap: from this line alone we can tell
 * (a) whether ANGLE routes through our wrapper and (b) whether glFinish is
 * resolvable — no need to wait for process exit. */
static void finish_first_hit(void) {
    if (n_swap_first_logged || !env_flag("GPU_FINISH_DEBUG", 0)) return;
    n_swap_first_logged = 1;
    FILE *f = fopen("/tmp/gpu-finish-shim.log", "a");
    if (f) {
        fprintf(f, "pid=%d FIRST eglSwapBuffers HIT enabled=%d glFinish=%s\n",
                (int)getpid(), finish_sync_enabled(),
                gl_finish_available == 1 ? "OK" :
                gl_finish_available == 0 ? "UNAVAILABLE" : "UNKNOWN");
        fclose(f);
    }
}

EGLBoolean eglSwapBuffers(EGLDisplay d, EGLSurface s) {
    fn_eglSwapBuffers real = captured_real_eglSwapBuffers;
    EGLBoolean r;
    if (!real) real = (fn_eglSwapBuffers)real_sym("eglSwapBuffers");
    if (!real) return (EGLBoolean)0;

    /* 1.0.14 FIX: glFinish must happen BEFORE the real swap. In 1.0.13 it ran
     * AFTER real(), i.e. after ANGLE had already committed the dma-buf to
     * KWin — a no-op for the scanout race. Waiting here guarantees the GPU has
     * finished rendering THIS frame before the buffer is presented. */
    if (finish_sync_enabled()) {
        fn_glFinish fin = resolve_glFinish();
        if (fin) { fin(); n_finish_calls++; gl_finish_available = 1; }
        else gl_finish_available = 0;
    }
    finish_first_hit();
    r = real(d, s);                       /* the actual ANGLE/HUAWEI swap */
    n_swap_calls++;
    return r;
}

static void finish_debug_dump(void) {
    if (!env_flag("GPU_FINISH_DEBUG", 0)) return;
    FILE *f = fopen("/tmp/gpu-finish-shim.log", "a");
    if (f) {
        fprintf(f, "pid=%d swap=%lu finish=%lu enabled=%d getfd=%lu getfd_ctx=%lu\n",
                (int)getpid(), n_swap_calls, n_finish_calls,
                finish_sync_enabled(), n_getfd_calls, n_getfd_with_ctx);
        fclose(f);
    }
}

static uint64_t target_modifier(void) {
    static uint64_t m = 0;
    if (!m) {
        const char *v = getenv("HISI_GBM_MODIFIER");
        m = v ? strtoull(v, NULL, 0) : KWIN_MOD_DEFAULT;
        if (!m) m = KWIN_MOD_DEFAULT;
    }
    return m;
}

/* ---------- fd -> bo cache (HUAWEI gbm_bo_import is a no-op) ------------
 * HUAWEI libGFX's gbm_bo_import() returns NULL for EVERY type (verified with
 * gbmimport.c on this machine). Chrome creates a bo via gbm_bo_create*, gets
 * its dma-buf fd, then calls gbm_bo_import to turn that fd back into a bo for
 * Wayland. We remember every bo we create together with its dma-buf identity,
 * and on import return the ORIGINAL bo instead of calling the broken HUAWEI
 * function.
 *
 * IMPORTANT: HUAWEI gbm_bo_get_fd() returns a NEW fd on EVERY call (verified
 * with diagnostics/gbm-fd-inode.c: 4 calls -> fd 5,6,7,8 but the SAME st_ino).
 * Keying the cache by fd number therefore NEVER matches the fd Chrome passes
 * to gbm_bo_import -> every import fell back to a freshly-created empty bo,
 * which shows up as frame jitter/tearing. Key by (st_dev, st_ino) instead.
 */
#define CACHE_MAX 256
static struct { dev_t dev; ino_t ino; gbm_bo *bo; uint32_t w, h, fmt; } bo_cache[CACHE_MAX];
static int bo_cache_n;
static pthread_mutex_t cache_lock = PTHREAD_MUTEX_INITIALIZER;

static void cache_bo(gbm_bo *bo, uint32_t w, uint32_t h, uint32_t fmt) {
    if (!bo) return;
    static fn_gbm_bo_get_fd gfd;
    if (!gfd) gfd = (fn_gbm_bo_get_fd)real_sym("gbm_bo_get_fd");
    int fd = gfd ? gfd(bo) : -1;
    if (fd < 0) return;
    struct stat st; memset(&st, 0, sizeof(st));
    int fr = fstat(fd, &st);
    close(fd);                 /* it's a dup; don't leak one per create */
    if (fr != 0) return;
    pthread_mutex_lock(&cache_lock);
    /* refresh an existing inode entry (same bo re-created) else append */
    int slot = -1;
    for (int i = 0; i < bo_cache_n; i++)
        if (bo_cache[i].dev == st.st_dev && bo_cache[i].ino == st.st_ino) { slot = i; break; }
    if (slot < 0 && bo_cache_n < CACHE_MAX) { slot = bo_cache_n++; }
    if (slot >= 0) {
        bo_cache[slot].dev = st.st_dev;
        bo_cache[slot].ino = st.st_ino;
        bo_cache[slot].bo  = bo;
        bo_cache[slot].w = w; bo_cache[slot].h = h; bo_cache[slot].fmt = fmt;
    }
    pthread_mutex_unlock(&cache_lock);
    if (debug_enabled())
        fprintf(stderr, "[gbm-hw] cache ino=%llu fd=%d bo=%p %ux%u fmt=0x%x\n",
                (unsigned long long)st.st_ino, fd, (void *)bo, w, h, fmt);
}
/* Look up the original bo for an imported dma-buf fd.
 *
 * Keying by (st_dev, st_ino) alone is NOT sufficient on HUAWEI libGFX:
 * gbm_bo_get_fd() hands out a NEW dup every call, and the kernel recycles
 * dma-buf inodes aggressively when Chrome streams many scroll tiles. If the
 * inode is reused, an import of a fresh bo can match a STALE cache entry and
 * get back an old bo -> a tile keeps showing scrolled-away content until a
 * mouse hover forces Chrome to repaint it.
 *
 * FIX: additionally require the imported geometry (w/h/fmt) to match the
 * cached entry, and prefer the newest matching slot (highest index). Callers
 * that don't know the geometry pass w=h=0, which keeps the old behaviour.
 */
static gbm_bo *lookup_bo(int fd, uint32_t w, uint32_t h, uint32_t fmt) {
    if (fd < 0) return NULL;
    struct stat st; memset(&st, 0, sizeof(st));
    if (fstat(fd, &st) != 0) return NULL;
    gbm_bo *found = NULL;
    int found_slot = -1;
    pthread_mutex_lock(&cache_lock);
    for (int i = 0; i < bo_cache_n; i++) {
        if (bo_cache[i].dev != st.st_dev || bo_cache[i].ino != st.st_ino)
            continue;
        /* geometry guard: reject stale inode reuse with a different buffer */
        if (w && h && (bo_cache[i].w != w || bo_cache[i].h != h ||
                       bo_cache[i].fmt != fmt))
            continue;
        found = bo_cache[i].bo;
        found_slot = i;          /* keep scanning: newest match wins */
    }
    pthread_mutex_unlock(&cache_lock);
    if (debug_enabled() && found)
        fprintf(stderr, "[gbm-hw] lookup fd=%d ino=%llu -> slot=%d bo=%p%s\n",
                fd, (unsigned long long)st.st_ino, found_slot, (void *)found,
                (w && h) ? " (geo-checked)" : "");
    return found;
}

/* ---------- wrapper: gbm_bo_get_fd_for_plane --------------------------- */
/* 1.0.15: GPU-side true sync at the REAL per-frame hook point.
 * eglSwapBuffers (1.0.13/14) NEVER fired in real Chrome (swap=0 for all 41
 * processes) — ANGLE binds it internally, bypassing dlsym+PLT. But
 * gbm_bo_get_fd_for_plane fires every frame on the GPU render thread WITH a
 * current EGL context (verified: GETFD_DIAG current_ctx=YES). Exporting the
 * dma-buf fd is exactly where the GPU must be done before KWin can scanout.
 * glFinish here blocks until this frame's GL commands retire, THEN we hand
 * the fd to Wayland -> commit. This is a real fence-free completion wait.
 *
 * Throttle: only the first getfd in a short window does glFinish (a frame may
 * export the same bo several times); avoids serializing within one frame. */
static void getfd_gpu_sync(void) {
    n_getfd_calls++;
    static long long last_finish_us = 0;
    static int have_ctx = -1;
    if (have_ctx < 0) {
        void *(*pfn_getctx)(void) = (void *(*)(void))dlsym(RTLD_DEFAULT, "eglGetCurrentContext");
        have_ctx = (pfn_getctx && pfn_getctx()) ? 1 : 0;
        if (have_ctx) n_getfd_with_ctx++;
    }
    if (!finish_sync_enabled() || !have_ctx) return;

    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    long long now = (long long)ts.tv_sec * 1000000LL + ts.tv_nsec / 1000LL;
    /* at most one glFinish per 2ms window (~one per frame at 60fps) */
    if (last_finish_us && (now - last_finish_us) < 2000) return;
    last_finish_us = now;

    fn_glFinish fin = resolve_glFinish();
    if (fin) { fin(); n_finish_calls++; }
    else gl_finish_available = 0;

    if (env_flag("GPU_FINISH_DEBUG", 0)) {
        /* first hit + every 200 finishes -> proves it runs per-frame */
        if (!n_getfd_first_logged || (n_finish_calls % 200) == 0) {
            n_getfd_first_logged = 1;
            FILE *f = fopen("/tmp/gpu-finish-shim.log", "a");
            if (f) {
                fprintf(f, "pid=%d GETFD_SYNC finish=%lu getfd=%lu glFinish=%s ctx=YES\n",
                        (int)getpid(), n_finish_calls, n_getfd_calls,
                        fin ? "OK" : "UNAVAILABLE");
                fclose(f);
            }
        }
    }
}

int gbm_bo_get_fd_for_plane(gbm_bo *bo, int plane) {
    getfd_gpu_sync();
    if (!env_flag("HISI_GBM_SHIM", 1) || !env_flag("HISI_GBM_PLANE_FD", 1)) {
        fn_plane_fd legacy = (fn_plane_fd)real_sym("gbm_bo_get_fd_for_plane");
        return legacy ? legacy(bo, plane) : -1;
    }
    static fn_gbm_bo_get_fd gfd;
    static fn_gbm_bo_get_device gd;
    static fn_gbm_device_get_fd gdfd;
    static fn_gbm_bo_get_handle_for_plane gh;
    static fn_drm_prime gp;
    if (!gfd) {
        gfd  = (fn_gbm_bo_get_fd)real_sym("gbm_bo_get_fd");
        gd   = (fn_gbm_bo_get_device)real_sym("gbm_bo_get_device");
        gdfd = (fn_gbm_device_get_fd)real_sym("gbm_device_get_fd");
        gh   = (fn_gbm_bo_get_handle_for_plane)real_sym("gbm_bo_get_handle_for_plane");
        gp   = (fn_drm_prime)real_sym("drmPrimeHandleToFD");
    }
    if (plane == 0 && gfd) {
        int fd = gfd(bo);
        if (debug_enabled())
            fprintf(stderr, "[gbm-hw] plane0 fd -> %d (%s)\n", fd,
                    fd >= 0 ? "OK" : strerror(errno));
        if (fd >= 0) return fd;
    }
    if (gd && gdfd && gh && gp) {
        gbm_device *dev = gd(bo);
        int devfd = dev ? gdfd(dev) : -1;
        uint32_t h = gh(bo, plane).u32;
        int fd = -1;
        int r = gp(devfd, h, O_CLOEXEC | O_RDWR, &fd);
        if (debug_enabled())
            fprintf(stderr, "[gbm-hw] prime devfd=%d handle=0x%x r=%d fd=%d\n",
                    devfd, h, r, fd);
        if (r == 0 && fd >= 0) return fd;
    }
    return -1;
}

/* ---------- wrapper: gbm_bo_create_with_modifiers --------------------- */
gbm_bo *gbm_bo_create_with_modifiers(gbm_device *dev, uint32_t w, uint32_t h,
        uint32_t format, const uint64_t *modifiers, uint32_t count) {
    static fn_gbm_bo_create_with_modifiers real;
    if (!real) real = (fn_gbm_bo_create_with_modifiers)real_sym("gbm_bo_create_with_modifiers");
    if (!env_flag("HISI_GBM_SHIM", 1) || !env_flag("HISI_GBM_CREATE_FIX", 1))
        return real ? real(dev, w, h, format, modifiers, count) : NULL;

    uint64_t fixed[8];
    uint32_t n = count > 8 ? 8 : count;
    int changed = 0;
    for (uint32_t i = 0; i < n; i++) {
        fixed[i] = modifiers[i];
        if (fixed[i] == 0 || fixed[i] == 0x00FFFFFFFFFFFFFFULL) {
            fixed[i] = target_modifier();
            changed = 1;
        }
    }
    if (n == 0) { fixed[0] = target_modifier(); n = 1; changed = 1; }
    gbm_bo *bo = real ? real(dev, w, h, format, changed ? fixed : modifiers, n) : NULL;
    if (debug_enabled())
        fprintf(stderr, "[gbm-hw] create_with_mod %ux%u fmt=0x%x count=%u "
                "mod0=0x%llx changed=%d -> %p\n",
                w, h, format, count,
                (unsigned long long)(n ? (changed ? fixed[0] : modifiers[0]) : 0),
                changed, (void *)bo);
    cache_bo(bo, w, h, format);
    return bo;
}

/* ---------- wrapper: gbm_bo_create (THE real-window fix) -------------- */
gbm_bo *gbm_bo_create(gbm_device *dev, uint32_t width, uint32_t height,
                      uint32_t format, uint32_t flags) {
    static fn_gbm_bo_create real;
    static fn_gbm_bo_create_with_modifiers real_mod;
    if (!real) real = (fn_gbm_bo_create)real_sym("gbm_bo_create");
    if (!real_mod) real_mod = (fn_gbm_bo_create_with_modifiers)real_sym("gbm_bo_create_with_modifiers");
    if (!env_flag("HISI_GBM_SHIM", 1) || !env_flag("HISI_GBM_CREATE_FIX", 1))
        return real ? real(dev, width, height, format, flags) : NULL;

    /* Real window pixmaps are >=64x64 and RGB formats. HUAWEI rejects
     * Scanout|Rendering|Texturing (flags=37) outright; route through the
     * modifiers entry point with KWin's only accepted modifier. */
    uint64_t m = target_modifier();
    if (real_mod && width >= 64 && height >= 64) {
        gbm_bo *bo = real_mod(dev, width, height, format, &m, 1);
        if (debug_enabled())
            fprintf(stderr, "[gbm-hw] create %ux%u fmt=0x%x flags=0x%x "
                    "-> with_mod 0x%llx -> %p\n",
                    width, height, format, flags, (unsigned long long)m, (void *)bo);
        if (bo) { cache_bo(bo, width, height, format); return bo; }
    }
    gbm_bo *bo = real ? real(dev, width, height, format, flags) : NULL;
    if (debug_enabled())
        fprintf(stderr, "[gbm-hw] create %ux%u fmt=0x%x flags=0x%x -> %p\n",
                width, height, format, flags, (void *)bo);
    cache_bo(bo, width, height, format);
    return bo;
}

/* ---------- wrapper: gbm_bo_get_modifier ------------------------------ */
uint64_t gbm_bo_get_modifier(gbm_bo *bo) {
    static fn_gbm_bo_get_modifier real;
    if (!real) real = (fn_gbm_bo_get_modifier)real_sym("gbm_bo_get_modifier");
    uint64_t m = real ? real(bo) : 0;
    if (!env_flag("HISI_GBM_SHIM", 1) || !env_flag("HISI_GBM_REPORT_MODIFIER", 1))
        return m;
    if (m == 0 || m == 0x00FFFFFFFFFFFFFFULL) {
        uint64_t want = target_modifier();
        if (debug_enabled())
            fprintf(stderr, "[gbm-hw] get_modifier 0x%llx -> 0x%llx\n",
                    (unsigned long long)m, (unsigned long long)want);
        return want;
    }
    return m;
}

/* ---------- wrapper: stride repair (THE jitter root cause) ------------
 * HUAWEI libGFX returns a BROKEN stride for bos created with the HISI
 * modifier (the only modifier KWin accepts):
 *   LINEAR bo: gbm_bo_get_stride()=1024, stride_for_plane(0)=1024
 *   HISI   bo: gbm_bo_get_stride()=0,    stride_for_plane(0)=32
 * for a 256x144 AR24 buffer, where 1024 (=256*4) is correct.
 * Chrome uses these values to lay out pixels and to build the dmabuf params
 * it hands to KWin. A wrong stride means every row is sampled at the wrong
 * offset -> static frames look fine but moving video/WebGL visibly jitters.
 * Repair any implausible stride (< width) to width*4 (Chrome window buffers
 * are 32bpp: AR24/XR24/AB24). HISI_GBM_STRIDE_FIX=0 disables for A/B.
 */
static uint32_t repair_stride(gbm_bo *bo, uint32_t got, const char *which) {
    if (!env_flag("HISI_GBM_SHIM", 1) || !env_flag("HISI_GBM_STRIDE_FIX", 1))
        return got;
    if (!bo || got >= 4) return got;           /* plausible already */
    static fn_gbm_bo_get_width gw;
    if (!gw) gw = (fn_gbm_bo_get_width)real_sym("gbm_bo_get_width");
    uint32_t w = gw ? gw(bo) : 0;
    if (!w) return got;
    uint32_t fixed = w * 4;
    if (debug_enabled())
        fprintf(stderr, "[gbm-hw] %s %u -> %u (w=%u)\n", which, got, fixed, w);
    return fixed;
}

uint32_t gbm_bo_get_stride(gbm_bo *bo) {
    static fn_gbm_bo_get_stride real;
    if (!real) real = (fn_gbm_bo_get_stride)real_sym("gbm_bo_get_stride");
    uint32_t s = real ? real(bo) : 0;
    return repair_stride(bo, s, "stride");
}

uint32_t gbm_bo_get_stride_for_plane(gbm_bo *bo, int plane) {
    static fn_gbm_bo_get_stride_for_plane real;
    if (!real) real = (fn_gbm_bo_get_stride_for_plane)real_sym("gbm_bo_get_stride_for_plane");
    uint32_t s = real ? real(bo, plane) : 0;
    return repair_stride(bo, s, "stride_plane");
}

/* ---------- wrapper: gbm_bo_import ------------------------------------ */
gbm_bo *gbm_bo_import(gbm_device *dev, uint32_t type, void *buffer,
                      uint32_t flags) {
    static fn_gbm_bo_import real;
    if (!real) real = (fn_gbm_bo_import)real_sym("gbm_bo_import");
    if (type != GBM_BO_IMPORT_FD_MODIFIER || !buffer ||
        !env_flag("HISI_GBM_SHIM", 1) || !env_flag("HISI_GBM_IMPORT_FIX", 1))
        return real ? real(dev, type, buffer, flags) : NULL;

    /* The incoming fd is at byte offset 16 of gbm_import_fd_modifier_data;
     * width/height/format at 0/4/8. Pass geometry so lookup_bo can reject a
     * stale inode that now belongs to a differently-sized scroll tile. */
    int in_fd = *(int *)((unsigned char *)buffer + 16);
    uint32_t in_w = *(uint32_t *)((unsigned char *)buffer + 0);
    uint32_t in_h = *(uint32_t *)((unsigned char *)buffer + 4);
    uint32_t in_fmt = *(uint32_t *)((unsigned char *)buffer + 8);
    gbm_bo *cached = lookup_bo(in_fd, in_w, in_h, in_fmt);
    if (cached) {
        if (debug_enabled())
            fprintf(stderr, "[gbm-hw] import fd=%d %ux%u fmt=0x%x -> cached bo=%p OK\n",
                    in_fd, in_w, in_h, in_fmt, (void *)cached);
        return cached;
    }

    unsigned char local[80];
    memset(local, 0, sizeof(local));
    memcpy(local, buffer, 64);
    uint64_t chrome_mod = *(uint64_t *)((unsigned char *)buffer + 56);
    if (chrome_mod == 0 || chrome_mod == 0x00FFFFFFFFFFFFFFULL)
        chrome_mod = target_modifier();
    *(uint64_t *)(local + 56) = chrome_mod;
    *(uint64_t *)(local + 64) = chrome_mod;
    gbm_bo *bo = real ? real(dev, type, local, flags) : NULL;
    if (debug_enabled())
        fprintf(stderr, "[gbm-hw] import fd=%d mod=0x%llx -> %p%s\n",
                in_fd, (unsigned long long)chrome_mod, (void *)bo,
                bo ? " OK" : " FAILED");
    /* Last resort: a fresh bo of the same geometry (import is broken here). */
    if (!bo) {
        uint32_t w = *(uint32_t *)((unsigned char *)buffer + 0);
        uint32_t h = *(uint32_t *)((unsigned char *)buffer + 4);
        uint32_t fmt = *(uint32_t *)((unsigned char *)buffer + 8);
        static fn_gbm_bo_create_with_modifiers cwm;
        if (!cwm) cwm = (fn_gbm_bo_create_with_modifiers)real_sym("gbm_bo_create_with_modifiers");
        if (cwm && w && h) {
            uint64_t m = chrome_mod;
            bo = cwm(dev, w, h, fmt, &m, 1);
            if (debug_enabled())
                fprintf(stderr, "[gbm-hw] import fallback fresh %ux%u fmt=0x%x -> %p\n",
                        w, h, fmt, (void *)bo);
        }
    }
    return bo;
}

/* ---------- dlsym hook: hand Chrome our GBM wrappers ------------------ */
void *dlsym(void *handle, const char *symbol) {
    void *(*rd)(void *, const char *) = real_dlsym_fn();
    if (!rd) return NULL;
    if (!env_flag("HISI_GBM_SHIM", 1)) return rd(handle, symbol);
    if (handle && symbol) {
        if (strcmp(symbol, "vaInitialize") == 0 && handle != RTLD_NEXT &&
            env_flag("HISI_VAAPI_SPOOF", 1)) {
            void *real = rd(handle, symbol);
            if (real)
                captured_real_vaInitialize =
                    (VAStatus (*)(VADisplay, int *, int *))real;
            if (debug_enabled())
                fprintf(stderr, "[gbm-hw] dlsym(vaInitialize) wrapped\n");
            return (void *)&vaInitialize;
        }
        if (strncmp(symbol, "gbm_", 4) == 0 && debug_enabled())
            fprintf(stderr, "[gbm-hw] dlsym(%s)\n", symbol);
        if (strcmp(symbol, "gbm_bo_get_fd_for_plane") == 0)
            return (void *)&gbm_bo_get_fd_for_plane;
        if (strcmp(symbol, "gbm_bo_create_with_modifiers") == 0)
            return (void *)&gbm_bo_create_with_modifiers;
        if (strcmp(symbol, "gbm_bo_create") == 0)
            return (void *)&gbm_bo_create;
        if (strcmp(symbol, "gbm_bo_get_modifier") == 0)
            return (void *)&gbm_bo_get_modifier;
        if (strcmp(symbol, "gbm_bo_get_stride") == 0)
            return (void *)&gbm_bo_get_stride;
        if (strcmp(symbol, "gbm_bo_get_stride_for_plane") == 0)
            return (void *)&gbm_bo_get_stride_for_plane;
        if (strcmp(symbol, "gbm_bo_import") == 0)
            return (void *)&gbm_bo_import;
        /* --- 方案 A: GPU-side true sync ------------------------------- */
        if (strcmp(symbol, "eglSwapBuffers") == 0 && finish_sync_enabled()) {
            void *real = rd(handle, symbol);
            if (real) captured_real_eglSwapBuffers = (fn_eglSwapBuffers)real;
            if (debug_enabled() || env_flag("GPU_FINISH_DEBUG", 0))
                fprintf(stderr, "[gbm-hw] dlsym(eglSwapBuffers) wrapped -> glFinish sync\n");
            return (void *)&eglSwapBuffers;
        }
        if (strcmp(symbol, "glFinish") == 0) {
            /* capture the real glFinish, but hand it back unchanged (we only
             * call it from our eglSwapBuffers wrapper, never wrap it). */
            void *real = rd(handle, symbol);
            if (real) captured_real_glFinish = (fn_glFinish)real;
            return real;
        }
    }
    return rd(handle, symbol);
}

/* ---- VAAPI vaInitialize wrapper (report 1.17 to pass Chrome's gate) ---- */
VAStatus vaInitialize(VADisplay dpy, int *major, int *minor)
{
    static VAStatus (*real)(VADisplay, int *, int *);
    if (!real) real = captured_real_vaInitialize;
    if (!real) real = (VAStatus (*)(VADisplay, int *, int *))
            real_dlsym_fn()(RTLD_NEXT, "vaInitialize");
    VAStatus st;
    if (real) st = real(dpy, major, minor);
    else { if (major) *major = 1; if (minor) *minor = 17; return VA_STATUS_SUCCESS; }
    if (st == VA_STATUS_SUCCESS && major && minor && *major == 1 && *minor < 17) {
        if (debug_enabled())
            fprintf(stderr, "[gbm-hw] vaInitialize 1.%d -> 1.17\n", *minor);
        *minor = 17;
    }
    return st;
}
